# Get the APK without a PC (all from your phone's browser)

1. Make a free account at github.com and tap **+ → New repository** (name it e.g. `kittenreader`, Public, no README).
2. Upload the project: unzip KittenReader.zip on your phone, open the new repo → **Add file → Upload files**,
   and upload the *contents* of the `KittenTTSApp` folder (including the hidden `.github` folder, `app`, `gradle`,
   `gradlew`, `*.kts`, `*.properties`). If your file manager hides `.github`, create the file
   `.github/workflows/build-apk.yml` with **Add file → Create new file** and paste the workflow from the zip.
   (Easiest: do the upload once from the "Desktop site" view of the browser.)
3. Open the **Actions** tab → **Build APK** → **Run workflow**. It takes roughly 15-40 minutes.
4. When it's green, open the repo's **Releases** → **KittenReader (latest build)** → tap **KittenReader.apk**.
5. Open the downloaded file; allow "Install unknown apps" for your browser when Android asks.

If the build turns red, open the failed step, copy the last ~30 lines of the log, and send them to me.
