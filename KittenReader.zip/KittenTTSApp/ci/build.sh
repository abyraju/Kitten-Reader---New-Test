#!/usr/bin/env bash
# Builds the APK in CI. Run from the project root (the folder containing gradlew).
set -euo pipefail
export ANDROID_NDK_HOME="${ANDROID_NDK_HOME:-${ANDROID_NDK_LATEST_HOME:-}}"
echo "NDK: $ANDROID_NDK_HOME"

git clone --depth 1 https://github.com/eugenehp/kittentts-rs.git rs

# Upstream's script builds the Rust lib WITHOUT the "espeak" feature, which removes
# kittentts_synthesize_to_file from the library. Enable it.
sed -i 's|^\(\s*\)--lib \\$|\1--lib \\\n\1--features espeak \\|' rs/android/build_rust_android.sh
grep -n -B1 -A1 -- "--features espeak" rs/android/build_rust_android.sh || { echo "patch failed"; exit 1; }

# Speech-quality fixes (real C espeak en-us with punctuation, keep punctuation/case, no cut-off of short clips)
python3 ci/patch_rust.py rs

bash rs/android/build_rust_android.sh

src=rs/android/KittenTTSApp/app/src/main
mkdir -p app/src/main/jniLibs app/src/main/assets
cp -r "$src/jniLibs/." app/src/main/jniLibs/
cp -r "$src/assets/." app/src/main/assets/ 2>/dev/null || true

# Verify the native libraries before spending time on Gradle.
# (Output goes to variables: "grep -q" closing a pipe early would trip pipefail.)
NM="$(ls "$ANDROID_NDK_HOME"/toolchains/llvm/prebuilt/*/bin/llvm-nm | head -1)"
READELF="$(ls "$ANDROID_NDK_HOME"/toolchains/llvm/prebuilt/*/bin/llvm-readelf | head -1)"
JNI=app/src/main/jniLibs/arm64-v8a/libkittentts_jni.so
ESP=app/src/main/jniLibs/arm64-v8a/libespeak-ng.so
JNI_SYMS="$("$NM" -D "$JNI")"
ESP_SYMS="$("$NM" -D "$ESP")"
JNI_DYN="$("$READELF" -d "$JNI")"
ASSETS="$(ls app/src/main/assets/)"

case "$JNI_SYMS" in *" T kittentts_synthesize_to_file"*) echo "OK: kittentts_synthesize_to_file is defined";;
  *) echo "ERROR: kittentts_synthesize_to_file is not defined in libkittentts_jni.so"; echo "$JNI_SYMS" | grep kittentts || true; exit 1;; esac
case "$JNI_SYMS" in *" U espeak_TextToPhonemes"*) ;;
  *) echo "ERROR: libkittentts_jni.so does not reference espeak_TextToPhonemes (patch not applied?)"; exit 1;; esac
case "$ESP_SYMS" in *" T espeak_TextToPhonemes"*) ;;
  *) echo "ERROR: libespeak-ng.so does not export espeak_TextToPhonemes"; exit 1;; esac
case "$JNI_DYN" in *"libespeak-ng.so"*) ;;
  *) echo "ERROR: libkittentts_jni.so does not list libespeak-ng.so as a dependency"; exit 1;; esac
case "$ASSETS" in *"espeak-ng-data.zip"*) ;;
  *) echo "ERROR: espeak-ng-data.zip missing from assets"; exit 1;; esac
echo "OK: C espeak is linked and shipped"

chmod +x gradlew
./gradlew --no-daemon assembleDebug
