#!/usr/bin/env bash
# Builds the APK in CI. Run from the project root (the folder containing gradlew).
set -euo pipefail
export ANDROID_NDK_HOME="${ANDROID_NDK_HOME:-${ANDROID_NDK_LATEST_HOME:-}}"
echo "NDK: $ANDROID_NDK_HOME"

git clone --depth 1 https://github.com/eugenehp/kittentts-rs.git rs

# Upstream's script builds the Rust lib WITHOUT the "espeak" feature, which removes
# kittentts_synthesize_to_file from the library. Enable it.
sed -i 's|^\(\s*\)--lib \\$|\1--lib \\\n\1--features espeak \\|' rs/android/build_rust_android.sh
grep -n -B1 -A1 -- "--features espeak" rs/android/build_rust_android.sh || { echo "patch failed"; exit 1; }

bash rs/android/build_rust_android.sh

src=rs/android/KittenTTSApp/app/src/main
mkdir -p app/src/main/jniLibs app/src/main/assets
cp -r "$src/jniLibs/." app/src/main/jniLibs/
cp -r "$src/assets/." app/src/main/assets/ 2>/dev/null || true

# Verify the symbol is really exported before spending time on Gradle.
NM="$(ls "$ANDROID_NDK_HOME"/toolchains/llvm/prebuilt/*/bin/llvm-nm | head -1)"
"$NM" -D app/src/main/jniLibs/arm64-v8a/libkittentts_jni.so | grep -q " T kittentts_synthesize_to_file" \
  || { echo "ERROR: kittentts_synthesize_to_file is not defined in libkittentts_jni.so"; "$NM" -D app/src/main/jniLibs/arm64-v8a/libkittentts_jni.so | grep kittentts; exit 1; }
echo "OK: kittentts_synthesize_to_file is defined"

chmod +x gradlew
./gradlew --no-daemon assembleDebug
