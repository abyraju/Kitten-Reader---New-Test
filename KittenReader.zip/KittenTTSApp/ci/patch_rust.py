#!/usr/bin/env python3
"""Patches the kittentts-rs checkout so speech quality matches the original Python KittenTTS.

1. phonemize.rs  - use the real C libespeak-ng (en-us) with punctuation preserved, instead of the
                   pure-Rust port (which dropped punctuation, used British English, left some words
                   unconverted and mangled apostrophes).
2. preprocess.rs - keep punctuation and case, and let espeak handle contractions. The default
                   pipeline stripped all punctuation (no pauses/intonation) and turned "John's"
                   into "john s".
3. model.rs      - do not chop 5000 samples (0.2 s) off very short clips (cut-off words).
"""
import pathlib, re, sys

root = pathlib.Path(sys.argv[1])
here = pathlib.Path(__file__).resolve().parent

# 1 ── phonemizer
p = root / "src/phonemize.rs"
s = p.read_text()
start = s.index('#[cfg(feature = "espeak")]\nmod inner {')
end = s.index("// ─── Public API (always compiled)")
s = s[:start] + (here / "phonemize_inner.rs").read_text() + s[end:]
p.write_text(s)

# 2 ── preprocessor defaults
p = root / "src/preprocess.rs"
s = p.read_text()
a = s.index("impl Default for PreprocessorConfig")
b = s.index("impl Default for TextPreprocessor")
block = s[a:b]
for field in ("lowercase", "expand_contractions", "remove_punctuation"):
    new, n = re.subn(rf"(\b{field}:\s*)true", r"\1false", block, count=1)
    assert n == 1, f"could not patch {field}"
    block = new
p.write_text(s[:a] + block + s[b:])

# 3 ── tail trim
p = root / "src/model.rs"
s = p.read_text()
old = "let trimmed_len = audio_flat.len().saturating_sub(TAIL_TRIM);"
assert old in s, "tail trim line not found"
s = s.replace(old, "let trimmed_len = audio_flat.len().saturating_sub(TAIL_TRIM.min(audio_flat.len() / 10));")
p.write_text(s)
print("patched", root)
