#[cfg(feature = "espeak")]
mod inner {
    //! Phonemizer backed by the real C libespeak-ng (the same engine the KittenTTS model was
    //! trained with), replacing the pure-Rust `espeak-ng` crate. Mirrors Python's
    //! `EspeakBackend(language="en-us", preserve_punctuation=True, with_stress=True)`:
    //! text is split at punctuation, each piece is phonemized, and the punctuation is put back.
    use std::ffi::{CStr, CString};
    use std::os::raw::{c_char, c_int, c_void};
    use std::sync::Mutex;

    use anyhow::{anyhow, Result};
    use fancy_regex::Regex;
    use once_cell::sync::{Lazy, OnceCell};

    use super::DATA_PATH;

    extern "C" {
        fn espeak_Initialize(output: c_int, buflength: c_int, path: *const c_char, options: c_int) -> c_int;
        fn espeak_SetVoiceByName(name: *const c_char) -> c_int;
        fn espeak_TextToPhonemes(textptr: *mut *const c_void, textmode: c_int, phonememode: c_int) -> *const c_char;
    }

    // espeak is not thread-safe: all calls go through this lock.
    static ENGINE: OnceCell<std::result::Result<Mutex<()>, String>> = OnceCell::new();

    static MARKS: Lazy<Regex> = Lazy::new(|| {
        Regex::new(r#"(\s*(?:[;:!?¡¿—…"«»“”(){}\[\]]|(?<![0-9])[,.]|[,.](?![0-9]))+\s*)+"#).unwrap()
    });
    static LANG_FLAG: Lazy<Regex> = Lazy::new(|| Regex::new(r"\([a-z\-]+\)").unwrap());

    fn init() -> &'static std::result::Result<Mutex<()>, String> {
        ENGINE.get_or_init(|| unsafe {
            // espeak wants the folder that CONTAINS "espeak-ng-data".
            let path = DATA_PATH.get().map(|p| {
                let is_data_dir = p.file_name().map(|n| n == "espeak-ng-data").unwrap_or(false);
                let base = if is_data_dir { p.parent().unwrap_or(p.as_path()) } else { p.as_path() };
                CString::new(base.to_string_lossy().as_bytes()).unwrap_or_default()
            });
            let ptr = path.as_ref().map_or(std::ptr::null(), |c| c.as_ptr());
            // 0x8000 = DONT_EXIT: report a missing data directory instead of killing the process.
            let rate = espeak_Initialize(2, 0, ptr, 0x8000);
            if rate < 0 {
                return Err(format!("espeak_Initialize failed ({rate}); data path = {:?}", DATA_PATH.get()));
            }
            let voice = CString::new("en-us").unwrap();
            let r = espeak_SetVoiceByName(voice.as_ptr());
            if r != 0 {
                return Err(format!("espeak_SetVoiceByName(en-us) failed ({r})"));
            }
            Ok(Mutex::new(()))
        })
    }

    pub(super) fn is_available() -> bool {
        init().is_ok()
    }

    /// Phonemize one punctuation-free piece of text.
    fn espeak_piece(text: &str) -> String {
        let c = match CString::new(text.replace('\0', " ")) {
            Ok(c) => c,
            Err(_) => return String::new(),
        };
        let mut ptr: *const c_void = c.as_ptr() as *const c_void;
        let mode: c_int = ((b'_' as c_int) << 8) | 0x02; // IPA, '_' between phonemes
        let mut parts: Vec<String> = Vec::new();
        let mut guard = 0;
        unsafe {
            while !ptr.is_null() && guard < 100_000 {
                let r = espeak_TextToPhonemes(&mut ptr, 1, mode);
                if !r.is_null() {
                    let s = CStr::from_ptr(r).to_string_lossy().into_owned();
                    if !s.is_empty() {
                        parts.push(s);
                    }
                }
                guard += 1;
            }
        }
        let joined = parts.join(" ").replace('\n', " ").replace('_', "");
        let joined = LANG_FLAG.replace_all(&joined, "").into_owned();
        joined.split_whitespace().collect::<Vec<_>>().join(" ")
    }

    pub(super) fn run_phonemize(text: &str) -> Result<String> {
        if text.trim().is_empty() {
            return Ok(String::new());
        }
        // "eighty-four", "well-known": hyphens join words in espeak; the old pipeline made them spaces.
        let text = text.replace('-', " ");
        let text = text.as_str();
        let engine = init().as_ref().map_err(|e| anyhow!("{e}"))?;
        let _guard = engine.lock().map_err(|_| anyhow!("espeak lock poisoned"))?;

        let mut out = String::new();
        let mut cursor = 0usize;
        for m in MARKS.find_iter(text) {
            let m = m.map_err(|e| anyhow!("punctuation regex: {e}"))?;
            if m.start() > cursor {
                let chunk = &text[cursor..m.start()];
                if !chunk.trim().is_empty() {
                    out.push_str(&espeak_piece(chunk));
                }
            }
            out.push_str(&m.as_str().split_whitespace().collect::<Vec<_>>().join(" "));
            out.push(' ');
            cursor = m.end();
        }
        if cursor < text.len() {
            let chunk = &text[cursor..];
            if !chunk.trim().is_empty() {
                out.push_str(&espeak_piece(chunk));
            }
        }
        Ok(out.trim().to_owned())
    }
}

