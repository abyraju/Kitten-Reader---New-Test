# KittenReader

An Android app that reads books aloud, fully on-device, using KittenTTS (via the
[kittentts-rs](https://github.com/eugenehp/kittentts-rs) Rust port + ONNX Runtime).

**Features:** import EPUB / TXT (Project Gutenberg headers handled) · chapter list ·
sentence highlighting that follows the voice · tap any sentence to start there ·
background playback with lock-screen/notification/headset controls · resumes where you
stopped · voice, speed and text size settings · sleep timer · works offline after first launch.
PDF is not supported (convert with Calibre).

## Build

This project is a drop-in replacement for `android/KittenTTSApp` in the kittentts-rs repo,
because that repo's build script puts the native libraries and model data there.

```bash
git clone https://github.com/eugenehp/kittentts-rs
cd kittentts-rs
# 1. Native libs (needs Rust, Android NDK r25+, CMake - see android/README.md in that repo)
rustup target add aarch64-linux-android
bash android/build_rust_android.sh

# 2. Overlay this app's sources on top of the example app (keeps the generated jniLibs/assets)
cp -r /path/to/KittenTTSApp/app/src/main/kotlin  android/KittenTTSApp/app/src/main/
cp -r /path/to/KittenTTSApp/app/src/main/res     android/KittenTTSApp/app/src/main/
cp    /path/to/KittenTTSApp/app/src/main/AndroidManifest.xml android/KittenTTSApp/app/src/main/
rm -f android/KittenTTSApp/app/src/main/kotlin/com/kittenml/kittentts/TTSEngine.kt \
      android/KittenTTSApp/app/src/main/kotlin/com/kittenml/kittentts/ui/MainScreen.kt \
      android/KittenTTSApp/app/src/main/kotlin/com/kittenml/kittentts/ui/AudioPlayerBar.kt

# 3. Build and install (or open android/KittenTTSApp in Android Studio)
cd android/KittenTTSApp && ./gradlew installDebug
```

The package name must stay `com.kittenml.kittentts`: the JNI bridge's function names depend on it.

On first launch the app extracts phoneme data and downloads the model from Hugging Face
(skipped if the build script bundled it in assets). Only arm64-v8a devices are supported.

## Notes
- If speech can't keep up on an older phone ("Preparing speech…" often), switch to the nano
  model: change `HF_BASE` and `ONNX_NAME` in `TtsRuntime.kt`.
- Voice names are whatever the model's `voices.npz` contains.
- Layout: `core/` pure-Kotlin parsing (EPUB, TXT, sentence splitting, WAV) with no Android
  dependencies; `BookStore` library + progress; `TtsRuntime` model setup + synthesis;
  `ReaderService` playback; `ui/` Compose screens.

## Multi-voice (different voice per character)
Settings (sliders icon) → "Different voice per character". The voice you picked narrates; quoted speech is
spoken by a voice per character. Speakers are found with rules (speech tags like "said Alice", "she asked",
action beats like "Alice smiled. “…”", and alternating dialogue), so it is English-only and imperfect;
open "Edit characters & voices…" to fix gender or voice per character. Unknown speakers use the narrator.
Uses double quotes only (“ ” or ").

## Speech-quality fixes (applied automatically by ci/build.sh via ci/patch_rust.py)
The upstream Rust port differs from the original Python KittenTTS in ways that hurt quality:
- its phonemizer was a pure-Rust eSpeak port: no punctuation, British accent, some words left as letters;
- its text clean-up removed all punctuation and turned "John's" into "john s";
- it always cut 0.2 s off the end of every clip.
The patch switches to the real C libespeak-ng (en-us, punctuation kept, same algorithm as Python's
phonemizer), keeps punctuation/case, lets eSpeak handle contractions, and limits the end trim on short clips.
