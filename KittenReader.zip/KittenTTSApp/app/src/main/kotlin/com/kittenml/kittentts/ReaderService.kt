package com.kittenml.kittentts

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.media.MediaMetadata
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.content.ContextCompat
import com.kittenml.kittentts.core.ChapterContent
import com.kittenml.kittentts.core.CastVoices
import com.kittenml.kittentts.core.DecodedAudio
import com.kittenml.kittentts.core.SpeechText
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.drop
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class ReaderState(
    val bookId: String? = null,
    val bookTitle: String = "",
    val chapterIndex: Int = 0,
    val chapterTitle: String = "",
    val chapterCount: Int = 0,
    val content: ChapterContent = ChapterContent.EMPTY,
    val chunk: Int = 0,
    /** True when the user wants audio (even if it is still being synthesized). */
    val playing: Boolean = false,
    /** True while waiting for the voice engine to produce the next sentence. */
    val buffering: Boolean = false,
    val finished: Boolean = false,
    val error: String? = null,
    /** Epoch millis at which the sleep timer pauses playback, or null. */
    val sleepEndsAt: Long? = null,
)

private sealed interface Item {
    class Chapter(val index: Int, val content: ChapterContent) : Item
    class Speech(val chunk: Int, val audio: DecodedAudio) : Item
    class Failure(val message: String) : Item
    data object End : Item
}

/**
 * Foreground service that streams synthesized speech to an AudioTrack, one sentence at a time,
 * synthesizing ahead while the current sentence plays. Exposes [state] for the UI and a
 * media-style notification + MediaSession for lock-screen and headset controls.
 */
class ReaderService : Service() {

    companion object {
        private const val TAG = "ReaderService"
        private const val CHANNEL_ID = "reading"
        private const val NOTIF_ID = 1
        private const val ACTION_OPEN = "kittenreader.OPEN"
        private const val ACTION_TOGGLE = "kittenreader.TOGGLE"
        private const val ACTION_PREV = "kittenreader.PREV_CHAPTER"
        private const val ACTION_NEXT = "kittenreader.NEXT_CHAPTER"
        private const val ACTION_STOP = "kittenreader.STOP"
        private const val EXTRA_BOOK = "book"
        private const val EXTRA_CHAPTER = "chapter"
        private const val EXTRA_CHUNK = "chunk"
        private const val EXTRA_PLAY = "play"

        private val _state = MutableStateFlow(ReaderState())
        val state: StateFlow<ReaderState> = _state.asStateFlow()

        @Volatile private var instance: ReaderService? = null

        /** Loads a book at the given position (or its saved position) and optionally starts reading. */
        fun open(context: Context, bookId: String, autoplay: Boolean, chapter: Int? = null, chunk: Int? = null) {
            val i = Intent(context, ReaderService::class.java).setAction(ACTION_OPEN)
                .putExtra(EXTRA_BOOK, bookId).putExtra(EXTRA_PLAY, autoplay)
            if (chapter != null) i.putExtra(EXTRA_CHAPTER, chapter)
            if (chunk != null) i.putExtra(EXTRA_CHUNK, chunk)
            ContextCompat.startForegroundService(context, i)
        }

        fun play() = instance?.play()
        fun pause() = instance?.pause()
        fun toggle() = instance?.let { if (_state.value.playing) it.pause() else it.play() }
        fun seek(chapter: Int, chunk: Int) = instance?.seek(chapter, chunk)
        fun stepChunk(delta: Int) = instance?.stepChunk(delta)
        fun stepChapter(delta: Int) = instance?.stepChapter(delta)
        fun setSleepTimer(minutes: Int?) = instance?.setSleepTimer(minutes)
        fun stop() = instance?.stopReading()
        /** Called when leaving the reader screen: shuts the service down unless audio is playing. */
        /** Re-speaks the current sentence with up-to-date voice settings (e.g. after editing the cast). */
        fun refresh() = instance?.refresh()
        fun closeIfPaused() { if (!_state.value.playing) instance?.stopReading() }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var playJob: Job? = null
    private var navJob: Job? = null
    private var sleepJob: Job? = null

    /** Gate used by the audio writer: false = pause. */
    private val wantAudio = MutableStateFlow(false)

    private lateinit var audioManager: AudioManager
    private lateinit var notificationManager: NotificationManager
    private var session: MediaSession? = null
    private var focusRequest: AudioFocusRequest? = null
    private var pausedByFocusLoss = false
    private var foregroundStarted = false

    // ─── Lifecycle ───────────────────────────────────────────────────────────

    override fun onCreate() {
        super.onCreate()
        instance = this
        BookStore.init(this)
        ReaderPrefs.init(this)
        TtsRuntime.start(this)
        audioManager = getSystemService(AUDIO_SERVICE) as AudioManager
        notificationManager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Reading", NotificationManager.IMPORTANCE_LOW)
        )
        session = MediaSession(this, "KittenReader").apply {
            setCallback(object : MediaSession.Callback() {
                override fun onPlay() = play()
                override fun onPause() = pause()
                override fun onSkipToNext() = stepChapter(1)
                override fun onSkipToPrevious() = stepChapter(-1)
                override fun onStop() = stopReading()
            })
            isActive = true
        }
        ContextCompat.registerReceiver(
            this, noisyReceiver, IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY),
            ContextCompat.RECEIVER_NOT_EXPORTED,
        )
        // Re-synthesize the current sentence when voice or speed changes while reading.
        scope.launch {
            combine(ReaderPrefs.voice, ReaderPrefs.speed, ReaderPrefs.multiVoice) { v, s, m -> Triple(v, s, m) }
                .drop(1)
                .collectLatest {
                    delay(400)
                    if (_state.value.playing && playJob?.isActive == true) startLoop()
                }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_OPEN -> {
                ensureForeground()
                val book = intent.getStringExtra(EXTRA_BOOK)
                if (book == null) { stopReading(); return START_NOT_STICKY }
                open(
                    book,
                    intent.getBooleanExtra(EXTRA_PLAY, false),
                    if (intent.hasExtra(EXTRA_CHAPTER)) intent.getIntExtra(EXTRA_CHAPTER, 0) else null,
                    if (intent.hasExtra(EXTRA_CHUNK)) intent.getIntExtra(EXTRA_CHUNK, 0) else null,
                )
            }
            ACTION_TOGGLE -> if (_state.value.playing) pause() else play()
            ACTION_NEXT -> stepChapter(1)
            ACTION_PREV -> stepChapter(-1)
            ACTION_STOP -> stopReading()
            else -> if (_state.value.bookId == null) stopSelf()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        saveProgress()
        playJob?.cancel()
        scope.cancel()
        try { unregisterReceiver(noisyReceiver) } catch (_: Exception) {}
        session?.release()
        session = null
        abandonFocus()
        _state.value = ReaderState()
        instance = null
        super.onDestroy()
    }

    private val noisyReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) { pause() }
    }

    // ─── Commands (main thread) ──────────────────────────────────────────────

    private fun open(bookId: String, autoplay: Boolean, chapter: Int?, chunk: Int?) {
        val cur = _state.value
        if (cur.bookId == bookId && chapter == null) {
            if (autoplay) play()
            return
        }
        val meta = BookStore.get(bookId)
        if (meta == null) { stopReading(); return }

        playJob?.cancel()
        wantAudio.value = false
        val saved = BookStore.getProgress(bookId)
        val ch = (chapter ?: saved.chapter).coerceIn(0, meta.chapters.lastIndex)
        val ck = chunk ?: if (chapter == null) saved.chunk else 0
        _state.value = ReaderState(bookId = bookId, bookTitle = meta.title, chapterCount = meta.chapters.size)
        loadAndShow(ch, ck, thenPlay = autoplay)
    }

    private fun play() {
        val s = _state.value
        if (s.bookId == null) return
        if (TtsRuntime.state.value != EngineState.Ready) {
            _state.update { it.copy(error = "The voice is still loading — try again in a moment.") }
            return
        }
        if (!requestFocus()) {
            _state.update { it.copy(error = "Another app is using the audio output.") }
            return
        }
        pausedByFocusLoss = false
        if (s.finished) {
            loadAndShow(0, 0, thenPlay = true)
            return
        }
        wantAudio.value = true
        _state.update { it.copy(playing = true, error = null) }
        if (playJob?.isActive != true) startLoop()
        refreshNotification()
    }

    private fun pause() {
        wantAudio.value = false
        if (!pausedByFocusLoss) abandonFocus()
        _state.update { it.copy(playing = false) }
        saveProgress()
        refreshNotification()
    }

    private fun seek(chapter: Int, chunk: Int) {
        val s = _state.value
        if (s.bookId == null) return
        loadAndShow(chapter.coerceIn(0, (s.chapterCount - 1).coerceAtLeast(0)), chunk, thenPlay = s.playing)
    }

    private fun stepChunk(delta: Int) {
        val s = _state.value
        val target = s.chunk + delta
        when {
            target < 0 && s.chapterIndex > 0 -> loadAndShow(s.chapterIndex - 1, Int.MAX_VALUE, s.playing)
            target >= s.content.chunks.size && s.chapterIndex < s.chapterCount - 1 ->
                loadAndShow(s.chapterIndex + 1, 0, s.playing)
            else -> loadAndShow(s.chapterIndex, target, s.playing)
        }
    }

    private fun stepChapter(delta: Int) {
        val s = _state.value
        if (s.bookId == null) return
        val target = s.chapterIndex + delta
        if (target < 0 || target >= s.chapterCount) return
        loadAndShow(target, 0, s.playing)
    }

    private fun setSleepTimer(minutes: Int?) {
        sleepJob?.cancel()
        if (minutes == null) {
            _state.update { it.copy(sleepEndsAt = null) }
            return
        }
        val ends = System.currentTimeMillis() + minutes * 60_000L
        _state.update { it.copy(sleepEndsAt = ends) }
        sleepJob = scope.launch {
            delay(minutes * 60_000L)
            _state.update { it.copy(sleepEndsAt = null) }
            pause()
        }
    }

    private fun refresh() {
        if (_state.value.playing && playJob?.isActive == true) startLoop()
    }

    fun stopReading() {
        playJob?.cancel()
        navJob?.cancel()
        sleepJob?.cancel()
        saveProgress()
        wantAudio.value = false
        abandonFocus()
        _state.value = ReaderState()
        if (foregroundStarted) {
            stopForeground(STOP_FOREGROUND_REMOVE)
            foregroundStarted = false
        }
        stopSelf()
    }

    /** Loads a chapter off the main thread, publishes it, and (re)starts reading if asked. */
    private fun loadAndShow(chapter: Int, chunk: Int, thenPlay: Boolean) {
        val id = _state.value.bookId ?: return
        val meta = BookStore.get(id) ?: return
        playJob?.cancel()
        navJob?.cancel()
        navJob = scope.launch {
            val content = try {
                withContext(Dispatchers.IO) { BookStore.loadChapter(id, chapter) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _state.update { it.copy(error = "Could not open this chapter: ${e.message}", playing = false) }
                wantAudio.value = false
                return@launch
            }
            val ck = chunk.coerceIn(0, (content.chunks.size - 1).coerceAtLeast(0))
            _state.update {
                it.copy(
                    chapterIndex = chapter,
                    chapterTitle = meta.chapters.getOrNull(chapter)?.title.orEmpty(),
                    content = content,
                    chunk = ck,
                    finished = false,
                    buffering = false,
                    error = null,
                )
            }
            saveProgress()
            if (thenPlay) {
                if (requestFocus()) {
                    wantAudio.value = true
                    _state.update { it.copy(playing = true) }
                    startLoop()
                } else {
                    wantAudio.value = false
                    _state.update { it.copy(playing = false, error = "Another app is using the audio output.") }
                }
            } else {
                _state.update { it.copy(playing = false) }
            }
            refreshNotification()
        }
    }

    private fun saveProgress() {
        val s = _state.value
        val id = s.bookId ?: return
        if (s.content.chunks.isEmpty() && s.chapterTitle.isEmpty()) return   // nothing loaded yet
        BookStore.saveProgress(id, s.chapterIndex, s.chunk)
    }

    // ─── Playback loop ───────────────────────────────────────────────────────

    private fun startLoop() {
        playJob?.cancel()
        val s = _state.value
        val bookId = s.bookId ?: return
        val startChapter = s.chapterIndex
        val startChunk = s.chunk
        playJob = scope.launch(Dispatchers.Default) {
            try {
                runPlayback(bookId, startChapter, startChunk)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "Playback failed", e)
                fail(e.message ?: e.javaClass.simpleName)
            }
        }
    }

    private fun fail(message: String) {
        wantAudio.value = false
        _state.update { it.copy(playing = false, buffering = false, error = message) }
        scope.launch { refreshNotification() }
    }

    private suspend fun runPlayback(bookId: String, startChapter: Int, startChunk: Int) = coroutineScope {
        val meta = BookStore.get(bookId) ?: return@coroutineScope
        val queue = Channel<Item>(capacity = 2)

        // Multi-voice: characters found in this book and their genders (improves "he said"/"she said").
        val multi = ReaderPrefs.multiVoice.value
        val cast = if (multi) withContext(Dispatchers.IO) { BookStore.getCast(bookId) } else emptyList()
        val known = cast.associate { it.name to it.gender }

        // Producer: synthesizes ahead of the audio that is currently playing.
        val producer = launch {
            try {
                var first = true
                for (ch in startChapter until meta.chapters.size) {
                    val content = BookStore.loadChapter(bookId, ch, known)
                    queue.send(Item.Chapter(ch, content))
                    val from = if (first) startChunk.coerceIn(0, (content.chunks.size - 1).coerceAtLeast(0)) else 0
                    first = false
                    for (i in from until content.chunks.size) {
                        val chunk = content.chunks[i]
                        if (!chunk.speakable) continue
                        val voices = TtsRuntime.voices.value
                        val narrator = ReaderPrefs.effectiveVoice(voices)
                            ?: throw SynthesisException("No voices available")
                        val voice = if (multi) {
                            CastVoices.voiceFor(chunk.speaker, CastVoices.resolve(cast, voices, narrator), narrator, voices) ?: narrator
                        } else narrator
                        val spoken = SpeechText.normalize(chunk.text)
                        if (spoken.none { it.isLetterOrDigit() }) continue
                        val speed = ReaderPrefs.speed.value
                        val audio = TtsRuntime.synthesize(spoken, voice, speed)
                        val pause = (SpeechText.pauseMs(content, i) * ReaderPrefs.pauseScale.value / speed).toInt()
                        queue.send(Item.Speech(i, audio.withSilence(pause)))
                    }
                }
                queue.send(Item.End)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                queue.send(Item.Failure(e.message ?: e.javaClass.simpleName))
            }
        }

        var track: AudioTrack? = null
        var trackRate = 0
        try {
            while (true) {
                var item = queue.tryReceive().getOrNull()
                if (item == null) {
                    _state.update { it.copy(buffering = true) }
                    item = queue.receive()
                    _state.update { it.copy(buffering = false) }
                }
                when (item) {
                    is Item.Chapter -> {
                        val title = meta.chapters.getOrNull(item.index)?.title.orEmpty()
                        _state.update {
                            it.copy(
                                chapterIndex = item.index, chapterTitle = title, content = item.content,
                                chunk = if (item.index == startChapter) startChunk.coerceAtLeast(0) else 0,
                            )
                        }
                        withContext(Dispatchers.Main) { refreshNotification() }
                    }
                    is Item.Speech -> {
                        _state.update { it.copy(chunk = item.chunk) }
                        BookStore.saveProgress(bookId, _state.value.chapterIndex, item.chunk)
                        if (track == null || trackRate != item.audio.sampleRate) {
                            track?.let { releaseTrack(it) }
                            track = newTrack(item.audio.sampleRate)
                            trackRate = item.audio.sampleRate
                            track.play()
                        }
                        writeAudio(track, item.audio)
                    }
                    is Item.Failure -> { fail(item.message); return@coroutineScope }
                    Item.End -> {
                        delay(600)   // let the audio buffer drain
                        _state.update { it.copy(playing = false, finished = true, buffering = false) }
                        wantAudio.value = false
                        withContext(Dispatchers.Main) { abandonFocus(); refreshNotification() }
                        return@coroutineScope
                    }
                }
            }
        } finally {
            producer.cancel()
            track?.let { releaseTrack(it) }
        }
    }

    private fun newTrack(rate: Int): AudioTrack {
        val minBytes = AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_FLOAT)
        val wanted = (rate * 0.4 * 4).toInt()          // ~0.4 s of float samples
        return AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_FLOAT)
                    .setSampleRate(rate)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setTransferMode(AudioTrack.MODE_STREAM)
            .setBufferSizeInBytes(maxOf(minBytes, wanted))
            .build()
    }

    private fun releaseTrack(t: AudioTrack) {
        try { t.pause(); t.flush() } catch (_: Exception) {}
        try { t.release() } catch (_: Exception) {}
    }

    /** Writes in quarter-second slices so pause and cancel take effect quickly. */
    private suspend fun writeAudio(track: AudioTrack, audio: DecodedAudio) {
        val slice = (audio.sampleRate / 4).coerceAtLeast(1)
        var off = 0
        while (off < audio.samples.size) {
            if (!wantAudio.value) {
                track.pause()
                wantAudio.first { it }
                track.play()
            }
            currentCoroutineContext().ensureActive()
            val n = minOf(slice, audio.samples.size - off)
            val written = track.write(audio.samples, off, n, AudioTrack.WRITE_BLOCKING)
            if (written < 0) throw IllegalStateException("Audio output error ($written)")
            off += written
        }
    }

    // ─── Audio focus ─────────────────────────────────────────────────────────

    private val focusListener = AudioManager.OnAudioFocusChangeListener { change ->
        when (change) {
            AudioManager.AUDIOFOCUS_LOSS -> { pausedByFocusLoss = false; pause() }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT, AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> {
                if (_state.value.playing) { pausedByFocusLoss = true; pause() }
            }
            AudioManager.AUDIOFOCUS_GAIN -> if (pausedByFocusLoss) { pausedByFocusLoss = false; play() }
        }
    }

    private fun requestFocus(): Boolean {
        val result = if (Build.VERSION.SDK_INT >= 26) {
            val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                .setOnAudioFocusChangeListener(focusListener)
                .build()
            focusRequest = req
            audioManager.requestAudioFocus(req)
        } else {
            @Suppress("DEPRECATION")
            audioManager.requestAudioFocus(focusListener, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN)
        }
        return result == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
    }

    private fun abandonFocus() {
        if (Build.VERSION.SDK_INT >= 26) {
            focusRequest?.let { audioManager.abandonAudioFocusRequest(it) }
            focusRequest = null
        } else {
            @Suppress("DEPRECATION")
            audioManager.abandonAudioFocus(focusListener)
        }
    }

    // ─── Notification / MediaSession ─────────────────────────────────────────

    private fun ensureForeground() {
        if (foregroundStarted) return
        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        } else {
            startForeground(NOTIF_ID, n)
        }
        foregroundStarted = true
    }

    private fun refreshNotification() {
        val s = _state.value
        if (s.bookId == null) return
        session?.setMetadata(
            MediaMetadata.Builder()
                .putString(MediaMetadata.METADATA_KEY_TITLE, s.chapterTitle.ifBlank { s.bookTitle })
                .putString(MediaMetadata.METADATA_KEY_ARTIST, s.bookTitle)
                .build()
        )
        val actions = PlaybackState.ACTION_PLAY or PlaybackState.ACTION_PAUSE or PlaybackState.ACTION_PLAY_PAUSE or
            PlaybackState.ACTION_SKIP_TO_NEXT or PlaybackState.ACTION_SKIP_TO_PREVIOUS or PlaybackState.ACTION_STOP
        session?.setPlaybackState(
            PlaybackState.Builder()
                .setActions(actions)
                .setState(
                    if (s.playing) PlaybackState.STATE_PLAYING else PlaybackState.STATE_PAUSED,
                    PlaybackState.PLAYBACK_POSITION_UNKNOWN, 1f,
                )
                .build()
        )
        if (foregroundStarted) notificationManager.notify(NOTIF_ID, buildNotification())
    }

    private fun action(code: String, icon: Int, title: String): Notification.Action {
        val pi = PendingIntent.getService(
            this, code.hashCode(), Intent(this, ReaderService::class.java).setAction(code),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        return Notification.Action.Builder(Icon.createWithResource(this, icon), title, pi).build()
    }

    private fun buildNotification(): Notification {
        val s = _state.value
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val b = Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(s.bookTitle.ifBlank { "KittenReader" })
            .setContentText(s.chapterTitle.ifBlank { "Getting ready…" })
            .setContentIntent(open)
            .setOnlyAlertOnce(true)
            .setOngoing(s.playing)
            .addAction(action(ACTION_PREV, R.drawable.ic_skip_previous, "Previous chapter"))
            .addAction(
                if (s.playing) action(ACTION_TOGGLE, R.drawable.ic_pause, "Pause")
                else action(ACTION_TOGGLE, R.drawable.ic_play_arrow, "Play")
            )
            .addAction(action(ACTION_NEXT, R.drawable.ic_skip_next, "Next chapter"))
            .addAction(action(ACTION_STOP, R.drawable.ic_close, "Close"))
        val style = Notification.MediaStyle().setShowActionsInCompactView(0, 1, 2)
        session?.let { style.setMediaSession(it.sessionToken) }
        b.setStyle(style)
        return b.build()
    }
}
