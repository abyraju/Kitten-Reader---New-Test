package com.kittenml.kittentts

import android.content.Context
import android.content.SharedPreferences
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Log
import com.kittenml.kittentts.core.ChapterContent
import com.kittenml.kittentts.core.EpubReader
import com.kittenml.kittentts.core.ParsedBook
import com.kittenml.kittentts.core.TxtImporter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

data class ChapterInfo(val title: String, val chars: Int)

data class BookMeta(
    val id: String,
    val title: String,
    val author: String?,
    val addedAt: Long,
    val chapters: List<ChapterInfo>,
) {
    val totalChars: Long get() = chapters.sumOf { it.chars.toLong() }
}

data class Progress(val chapter: Int, val chunk: Int, val updatedAt: Long)

/**
 * The on-device library. Each book lives in filesDir/books/<id>/ as meta.json plus one
 * plain-text file per chapter (one paragraph per line). Reading progress is kept in
 * SharedPreferences.
 */
object BookStore {

    private const val TAG = "BookStore"
    private const val MAX_IMPORT_BYTES = 150L * 1024 * 1024

    private lateinit var root: File
    private lateinit var prefs: SharedPreferences

    private val _books = MutableStateFlow<List<BookMeta>>(emptyList())
    val books: StateFlow<List<BookMeta>> = _books.asStateFlow()

    private val _progress = MutableStateFlow<Map<String, Progress>>(emptyMap())
    val progress: StateFlow<Map<String, Progress>> = _progress.asStateFlow()

    fun init(context: Context) {
        if (::root.isInitialized) return
        root = File(context.filesDir, "books").also { it.mkdirs() }
        prefs = context.getSharedPreferences("progress", Context.MODE_PRIVATE)
        _progress.value = loadProgress()
        _books.value = loadAll()
    }

    fun get(id: String): BookMeta? = _books.value.firstOrNull { it.id == id }

    fun getProgress(id: String): Progress = _progress.value[id] ?: Progress(0, 0, 0L)

    fun saveProgress(id: String, chapter: Int, chunk: Int) {
        val p = Progress(chapter, chunk, System.currentTimeMillis())
        _progress.update { it + (id to p) }
        prefs.edit().putString(id, "${p.chapter}:${p.chunk}:${p.updatedAt}").apply()
    }

    fun loadChapter(bookId: String, index: Int): ChapterContent {
        val f = File(File(root, bookId), chapterFileName(index))
        return ChapterContent.fromStoredText(f.readText())
    }

    fun delete(id: String) {
        File(root, id).deleteRecursively()
        prefs.edit().remove(id).apply()
        _progress.update { it - id }
        _books.update { list -> list.filter { it.id != id } }
    }

    /** Copies the picked file, parses it (EPUB or plain text) and stores it. Runs on the IO dispatcher. */
    suspend fun import(context: Context, uri: Uri): BookMeta = withContext(Dispatchers.IO) {
        val resolver = context.contentResolver
        val displayName = resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
        val baseTitle = (displayName ?: "Untitled").substringBeforeLast('.').replace('_', ' ').trim()
            .ifEmpty { "Untitled" }

        val tmp = File(context.cacheDir, "import_${System.nanoTime()}.bin")
        val dir = File(root, UUID.randomUUID().toString())
        try {
            val input = resolver.openInputStream(uri) ?: throw IllegalStateException("Cannot open the selected file")
            input.use { src ->
                tmp.outputStream().use { dst ->
                    val buf = ByteArray(64 * 1024)
                    var total = 0L
                    while (true) {
                        val n = src.read(buf)
                        if (n < 0) break
                        total += n
                        require(total <= MAX_IMPORT_BYTES) { "File is too large (limit 150 MB)" }
                        dst.write(buf, 0, n)
                    }
                }
            }

            val head = tmp.inputStream().use { ins -> ByteArray(5).also { ins.read(it) } }
            require(String(head, Charsets.ISO_8859_1) != "%PDF-") {
                "PDF files aren't supported yet. Convert it to EPUB or TXT first (for example with Calibre)."
            }
            val isZip = head[0] == 'P'.code.toByte() && head[1] == 'K'.code.toByte()
            val parsed: ParsedBook = if (isZip) EpubReader.read(tmp, baseTitle)
            else TxtImporter.parse(tmp.readBytes(), baseTitle)

            check(dir.mkdirs()) { "Cannot create storage for the book" }
            val infos = parsed.chapters.mapIndexed { i, ch ->
                val text = ch.paragraphs.joinToString("\n")
                File(dir, chapterFileName(i)).writeText(text)
                ChapterInfo(ch.title, text.length)
            }
            val meta = BookMeta(
                id = dir.name,
                title = parsed.title.ifBlank { baseTitle },
                author = parsed.author,
                addedAt = System.currentTimeMillis(),
                chapters = infos,
            )
            File(dir, "meta.json").writeText(toJson(meta).toString())
            _books.update { listOf(meta) + it }
            meta
        } catch (e: Exception) {
            dir.deleteRecursively()
            Log.w(TAG, "Import failed", e)
            throw e
        } finally {
            tmp.delete()
        }
    }

    // ─── persistence helpers ─────────────────────────────────────────────────

    private fun chapterFileName(i: Int) = "ch_%04d.txt".format(i)

    private fun toJson(m: BookMeta) = JSONObject().apply {
        put("id", m.id)
        put("title", m.title)
        put("author", m.author ?: JSONObject.NULL)
        put("addedAt", m.addedAt)
        put("chapters", JSONArray().apply {
            m.chapters.forEach { put(JSONObject().put("title", it.title).put("chars", it.chars)) }
        })
    }

    private fun loadAll(): List<BookMeta> =
        (root.listFiles() ?: emptyArray())
            .mapNotNull { dir ->
                try {
                    val o = JSONObject(File(dir, "meta.json").readText())
                    val arr = o.getJSONArray("chapters")
                    BookMeta(
                        id = o.getString("id"),
                        title = o.getString("title"),
                        author = if (o.isNull("author")) null else o.getString("author"),
                        addedAt = o.getLong("addedAt"),
                        chapters = (0 until arr.length()).map {
                            val c = arr.getJSONObject(it)
                            ChapterInfo(c.getString("title"), c.getInt("chars"))
                        },
                    )
                } catch (e: Exception) {
                    Log.w(TAG, "Skipping unreadable book folder ${dir.name}", e)
                    null
                }
            }
            .sortedByDescending { it.addedAt }

    private fun loadProgress(): Map<String, Progress> {
        val out = HashMap<String, Progress>()
        for ((key, value) in prefs.all) {
            val parts = (value as? String)?.split(':') ?: continue
            if (parts.size != 3) continue
            val ch = parts[0].toIntOrNull() ?: continue
            val ck = parts[1].toIntOrNull() ?: continue
            val t = parts[2].toLongOrNull() ?: continue
            out[key] = Progress(ch, ck, t)
        }
        return out
    }
}
