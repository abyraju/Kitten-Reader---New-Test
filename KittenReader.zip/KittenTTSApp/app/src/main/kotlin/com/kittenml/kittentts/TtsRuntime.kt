package com.kittenml.kittentts

import android.content.Context
import android.util.Log
import com.kittenml.kittentts.core.DecodedAudio
import com.kittenml.kittentts.core.Wav
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

sealed interface EngineState {
    data class Downloading(val fraction: Float, val label: String) : EngineState
    data object Loading : EngineState
    data object Ready : EngineState
    data class Error(val message: String) : EngineState
}

class SynthesisException(message: String) : Exception(message)

/**
 * Process-wide owner of the Rust model handle. Sets up espeak-ng data and the model files
 * (bundled in assets or downloaded on first launch), loads the model, and turns text into audio.
 * Setup logic is adapted from the kittentts-rs example app.
 */
object TtsRuntime {

    private const val TAG = "TtsRuntime"

    // To try another KittenTTS checkpoint, change the repo and the ONNX file name here.
    private const val HF_BASE = "https://huggingface.co/KittenML/kitten-tts-mini-0.8/resolve/main"
    private const val ONNX_NAME = "kitten_tts_mini_v0_8.onnx"

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val _state = MutableStateFlow<EngineState>(EngineState.Downloading(0f, "Starting…"))
    val state: StateFlow<EngineState> = _state.asStateFlow()

    private val _voices = MutableStateFlow<List<String>>(emptyList())
    val voices: StateFlow<List<String>> = _voices.asStateFlow()

    @Volatile private var handle = 0L
    private val synthLock = Mutex()
    private var app: Context? = null

    fun start(context: Context) {
        if (app != null) return
        val ctx = context.applicationContext
        app = ctx
        scope.launch { setUp(ctx) }
    }

    fun retry() {
        val ctx = app ?: return
        if (_state.value !is EngineState.Error) return
        scope.launch { setUp(ctx) }
    }

    // ─── Synthesis ───────────────────────────────────────────────────────────

    /** Blocking native call on a background thread; one at a time. */
    suspend fun synthesize(text: String, voice: String, speed: Float): DecodedAudio {
        val ctx = app ?: throw SynthesisException("Voice engine was not started")
        return withContext(Dispatchers.Default) {
            synthLock.withLock {
                val h = handle
                if (h == 0L) throw SynthesisException("Voice engine is not ready")
                val out = File(ctx.cacheDir, "tts_${System.nanoTime()}.wav")
                try {
                    val err = KittenTtsLib.nativeSynthesizeToFile(h, text, voice, speed, out.absolutePath)
                    if (err != null) throw SynthesisException(err)
                    Wav.decode(out.readBytes())
                } finally {
                    out.delete()
                }
            }
        }
    }

    // ─── Setup ───────────────────────────────────────────────────────────────

    private fun setUp(ctx: Context) {
        if (handle != 0L) return
        _state.value = EngineState.Downloading(0f, "Starting…")

        KittenTtsLib.loadError?.let {
            _state.value = EngineState.Error(it)
            return
        }

        val hasEspeakZip = try {
            ctx.assets.open("espeak-ng-data.zip").close(); true
        } catch (_: Exception) {
            false
        }
        if (!hasEspeakZip) {
            _state.value = EngineState.Error("espeak-ng-data.zip is missing from the app, so speech cannot start. Rebuild the app.")
            return
        }

        val espeakDir = File(ctx.filesDir, "espeak-ng-data")
        try {
            extractEspeakData(ctx, espeakDir)
            ensureModels(ctx)
        } catch (e: Exception) {
            Log.e(TAG, "Setup failed", e)
            _state.value = EngineState.Error("Setup failed: ${e.message}")
            return
        }

        _state.value = EngineState.Loading
        KittenTtsLib.nativeSetEspeakDataPath(espeakDir.absolutePath)
        val h = KittenTtsLib.nativeModelLoad(
            File(ctx.filesDir, ONNX_NAME).absolutePath,
            File(ctx.filesDir, "voices.npz").absolutePath,
        )
        if (h == 0L) {
            _state.value = EngineState.Error("Failed to load the model — check logcat (tag KittenTTS_JNI).")
            return
        }
        handle = h
        _voices.value = parseJsonStringArray(KittenTtsLib.nativeModelVoices(h))
        Log.i(TAG, "Model loaded; voices = ${_voices.value}")
        _state.value = EngineState.Ready
    }

    private fun extractEspeakData(ctx: Context, dir: File) {
        val sentinel = File(dir, "phontab")
        if (sentinel.exists()) return
        _state.value = EngineState.Downloading(0f, "Extracting phoneme data…")
        dir.deleteRecursively()
        dir.mkdirs()
        val root = dir.canonicalPath + File.separator
        ctx.assets.open("espeak-ng-data.zip").use { asset ->
            ZipInputStream(asset).use { zip ->
                var entry = zip.nextEntry
                while (entry != null) {
                    val name = entry.name.removePrefix("espeak-ng-data/")
                    if (name.isNotBlank()) {
                        val dest = File(dir, name)
                        require(dest.canonicalPath.startsWith(root)) { "Bad zip entry: ${entry.name}" }   // zip-slip guard
                        if (entry.isDirectory) dest.mkdirs() else {
                            dest.parentFile?.mkdirs()
                            FileOutputStream(dest).use { zip.copyTo(it) }
                        }
                    }
                    zip.closeEntry()
                    entry = zip.nextEntry
                }
            }
        }
        check(sentinel.exists()) { "espeak-ng-data extracted but phontab is missing" }
    }

    private fun ensureModels(ctx: Context) {
        val files = listOf(ONNX_NAME, "voices.npz", "config.json")

        // Prefer files bundled in assets by the build script.
        for (name in files) {
            val dest = File(ctx.filesDir, name)
            if (!dest.exists()) {
                try {
                    ctx.assets.open("models/$name").use { src -> dest.outputStream().use { src.copyTo(it) } }
                } catch (_: Exception) {
                    dest.delete()   // not bundled — download below
                }
            }
        }

        val missing = files.filter { !File(ctx.filesDir, it).exists() }
        missing.forEachIndexed { idx, name ->
            val label = "Downloading $name…"
            val base = idx.toFloat() / missing.size
            _state.value = EngineState.Downloading(base, label)
            val tmp = File(ctx.cacheDir, "$name.tmp")
            download("$HF_BASE/$name", tmp) { done, total ->
                if (total > 0) {
                    val f = base + (done.toFloat() / total) / missing.size
                    _state.value = EngineState.Downloading(f.coerceIn(0f, 1f), label)
                }
            }
            check(tmp.renameTo(File(ctx.filesDir, name))) { "Could not save $name" }
        }
    }

    /** Downloads [urlStr] to [dest], following cross-host redirects (HuggingFace → CDN). */
    private fun download(urlStr: String, dest: File, onProgress: (Long, Long) -> Unit) {
        var location = urlStr
        var conn: HttpURLConnection? = null
        for (hop in 0 until 10) {
            val c = URL(location).openConnection() as HttpURLConnection
            c.connectTimeout = 15_000
            c.readTimeout = 60_000
            c.instanceFollowRedirects = false
            c.setRequestProperty("User-Agent", "KittenReader-Android/1.0")
            c.connect()
            val code = c.responseCode
            if (code in 300..399) {
                location = c.getHeaderField("Location") ?: error("Redirect without Location header")
                c.disconnect()
            } else if (code == 200) {
                conn = c
                break
            } else {
                c.disconnect()
                error("HTTP $code while downloading $urlStr")
            }
        }
        val c = conn ?: error("Too many redirects for $urlStr")
        val total = c.contentLengthLong
        var done = 0L
        c.inputStream.use { input ->
            FileOutputStream(dest).use { output ->
                val buf = ByteArray(32 * 1024)
                while (true) {
                    val n = input.read(buf)
                    if (n < 0) break
                    output.write(buf, 0, n)
                    done += n
                    onProgress(done, total)
                }
            }
        }
        c.disconnect()
    }

    /** Voice list arrives as a compact JSON array of strings. */
    private fun parseJsonStringArray(json: String?): List<String> {
        if (json.isNullOrBlank()) return emptyList()
        return json.trim().removePrefix("[").removeSuffix("]")
            .split(",")
            .map { it.trim().removeSurrounding("\"") }
            .filter { it.isNotBlank() }
    }
}
