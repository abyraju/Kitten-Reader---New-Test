package com.kittenml.kittentts.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.kittenml.kittentts.BookMeta
import com.kittenml.kittentts.BookStore
import com.kittenml.kittentts.EngineState
import com.kittenml.kittentts.R
import com.kittenml.kittentts.TtsRuntime
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LibraryScreen(onOpen: (String) -> Unit, nowReadingId: String?) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val snackbar = remember { SnackbarHostState() }
    val books by BookStore.books.collectAsState()
    val progress by BookStore.progress.collectAsState()
    val engine by TtsRuntime.state.collectAsState()
    var importing by remember { mutableStateOf(false) }
    var toDelete by remember { mutableStateOf<BookMeta?>(null) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        importing = true
        scope.launch {
            try {
                BookStore.import(context, uri)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                snackbar.showSnackbar(e.message ?: "Could not import this file")
            } finally {
                importing = false
            }
        }
    }

    Scaffold(
        topBar = { TopAppBar(title = { Text("KittenReader") }) },
        snackbarHost = { SnackbarHost(snackbar) },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { if (!importing) picker.launch(arrayOf("*/*")) },
                icon = { Icon(painterResource(R.drawable.ic_add), contentDescription = null) },
                text = { Text(if (importing) "Importing…" else "Add book") },
            )
        },
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            EngineBanner(engine)
            if (importing) LinearProgressIndicator(Modifier.fillMaxWidth())

            if (books.isEmpty()) {
                Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
                    Text(
                        "No books yet.\nTap “Add book” and pick an EPUB or TXT file.",
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            } else {
                LazyColumn(
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp, 8.dp, 16.dp, 96.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    items(books, key = { it.id }) { book ->
                        val p = progress[book.id]
                        val fraction = if (p == null || book.totalChars == 0L) 0f else {
                            val before = book.chapters.take(p.chapter).sumOf { it.chars.toLong() }
                            (before.toFloat() / book.totalChars).coerceIn(0f, 1f)
                        }
                        BookRow(book, fraction, started = p != null, playing = book.id == nowReadingId,
                            onClick = { onOpen(book.id) }, onDelete = { toDelete = book })
                    }
                }
            }
        }
    }

    toDelete?.let { book ->
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text("Delete book?") },
            text = { Text("“${book.title}” and your reading position will be removed from this device.") },
            confirmButton = {
                TextButton(onClick = {
                    if (book.id == nowReadingId) com.kittenml.kittentts.ReaderService.stop()
                    BookStore.delete(book.id)
                    toDelete = null
                }) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text("Cancel") } },
        )
    }
}

@Composable
private fun BookRow(book: BookMeta, fraction: Float, started: Boolean, playing: Boolean, onClick: () -> Unit, onDelete: () -> Unit) {
    Card(Modifier.fillMaxWidth().clickable(onClick = onClick)) {
        Row(Modifier.padding(start = 16.dp, top = 12.dp, bottom = 12.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(book.title, style = MaterialTheme.typography.titleMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                book.author?.let {
                    Text(it, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                Text(
                    buildString {
                        append("${book.chapters.size} chapters")
                        if (playing) append(" · now reading") else if (started) append(" · ${(fraction * 100).toInt()}%")
                    },
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 4.dp),
                )
                if (started) {
                    LinearProgressIndicator(progress = { fraction }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp, end = 12.dp))
                }
            }
            IconButton(onClick = onDelete) {
                Icon(painterResource(R.drawable.ic_delete), contentDescription = "Delete ${book.title}")
            }
        }
    }
}

@Composable
private fun EngineBanner(state: EngineState) {
    when (state) {
        is EngineState.Ready -> Unit
        is EngineState.Loading -> Banner { Spinner(); Text("Loading voice…") }
        is EngineState.Downloading -> Column(Modifier.fillMaxWidth().padding(16.dp)) {
            Text(state.label, style = MaterialTheme.typography.bodyMedium)
            LinearProgressIndicator(progress = { state.fraction }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp))
            Text("First launch only — you can add books meanwhile.", style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 4.dp))
        }
        is EngineState.Error -> Column(Modifier.fillMaxWidth().padding(16.dp)) {
            Text(state.message, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
            Button(onClick = { TtsRuntime.retry() }, modifier = Modifier.padding(top = 8.dp)) { Text("Retry") }
        }
    }
}

@Composable
private fun Banner(content: @Composable () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) { content() }
}

@Composable
private fun Spinner() = CircularProgressIndicator(Modifier.padding(end = 4.dp), strokeWidth = 2.dp)
