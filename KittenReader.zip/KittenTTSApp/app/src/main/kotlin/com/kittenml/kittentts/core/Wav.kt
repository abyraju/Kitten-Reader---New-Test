package com.kittenml.kittentts.core

class DecodedAudio(val samples: FloatArray, val sampleRate: Int) {
    /** Copy of this audio followed by [ms] milliseconds of silence. */
    fun withSilence(ms: Int): DecodedAudio {
        val extra = (sampleRate.toLong() * ms / 1000).toInt().coerceAtLeast(0)
        return if (extra == 0) this else DecodedAudio(samples.copyOf(samples.size + extra), sampleRate)
    }
}

/**
 * Decodes the WAV files written by the Rust library into float samples.
 * Handles 16-bit PCM (what it writes today) and 32-bit float (what its header comment
 * claims), plus WAVE_FORMAT_EXTENSIBLE and multi-channel input (mixed down to mono).
 */
object Wav {

    private const val PCM = 1
    private const val FLOAT = 3
    private const val EXTENSIBLE = 0xFFFE

    fun decode(b: ByteArray): DecodedAudio {
        require(b.size >= 12 && tag(b, 0) == "RIFF" && tag(b, 8) == "WAVE") { "Not a WAV file" }

        var format = 0
        var channels = 1
        var rate = 24_000
        var bits = 16
        var haveFmt = false

        var pos = 12
        while (pos + 8 <= b.size) {
            val id = tag(b, pos)
            var size = le32(b, pos + 4).toLong() and 0xFFFFFFFFL
            val body = pos + 8

            if (id == "fmt ") {
                require(size >= 16 && body + 16 <= b.size) { "Truncated WAV fmt chunk" }
                format = le16(b, body)
                channels = le16(b, body + 2)
                rate = le32(b, body + 4)
                bits = le16(b, body + 14)
                if (format == EXTENSIBLE && size >= 26 && body + 26 <= b.size) {
                    format = le16(b, body + 24)   // first two bytes of the sub-format GUID
                }
                haveFmt = true
            } else if (id == "data") {
                require(haveFmt) { "WAV data chunk before fmt chunk" }
                val available = (b.size - body).toLong()
                if (size > available) size = available     // streamed / truncated files
                return DecodedAudio(convert(b, body, size.toInt(), format, channels, bits), rate)
            }

            if (size > b.size) break
            pos = body + size.toInt() + (size.toInt() and 1)
        }
        throw IllegalArgumentException("WAV has no data chunk")
    }

    private fun convert(b: ByteArray, off: Int, size: Int, format: Int, channels: Int, bits: Int): FloatArray {
        require(channels >= 1) { "Bad channel count $channels" }
        require((format == PCM && bits == 16) || (format == FLOAT && bits == 32)) {
            "Unsupported WAV encoding (format=$format, bits=$bits)"
        }
        val bytesPerSample = bits / 8
        val frames = size / (bytesPerSample * channels)
        val out = FloatArray(frames)
        var p = off
        for (f in 0 until frames) {
            var sum = 0f
            for (c in 0 until channels) {
                sum += if (format == PCM) {
                    ((b[p + 1].toInt() shl 8) or (b[p].toInt() and 0xFF)).toShort() / 32768f
                } else {
                    Float.fromBits(le32(b, p))
                }
                p += bytesPerSample
            }
            out[f] = if (channels == 1) sum else sum / channels
        }
        return out
    }

    private fun tag(b: ByteArray, o: Int) = String(b, o, 4, Charsets.ISO_8859_1)
    private fun le16(b: ByteArray, o: Int) = (b[o].toInt() and 0xFF) or ((b[o + 1].toInt() and 0xFF) shl 8)
    private fun le32(b: ByteArray, o: Int) =
        (b[o].toInt() and 0xFF) or ((b[o + 1].toInt() and 0xFF) shl 8) or
            ((b[o + 2].toInt() and 0xFF) shl 16) or ((b[o + 3].toInt() and 0xFF) shl 24)
}
