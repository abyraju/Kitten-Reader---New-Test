package com.kittenml.kittentts.core

/**
 * One speakable piece of a chapter (usually a sentence, or a few short ones).
 * [start]/[end] index into the text of paragraph [paragraph], so the UI can highlight it.
 */
data class Chunk(
    val paragraph: Int,
    val start: Int,
    val end: Int,
    val text: String,
    /** Who speaks this piece: null = narrator, otherwise a character key (see [Attributor]). */
    val speaker: String? = null,
) {
    /** False for things like "* * *" that contain nothing to pronounce. */
    val speakable: Boolean get() = text.any { it.isLetterOrDigit() }
}

/** A chapter ready for display (paragraphs) and for reading aloud (chunks). */
class ChapterContent(val paragraphs: List<String>, val chunks: List<Chunk>) {

    /** Index of the first chunk in each paragraph, or -1 if a paragraph has none. */
    val firstChunkInParagraph: IntArray = IntArray(paragraphs.size) { -1 }.also { arr ->
        chunks.forEachIndexed { i, c -> if (arr[c.paragraph] == -1) arr[c.paragraph] = i }
    }

    companion object {
        val EMPTY = ChapterContent(emptyList(), emptyList())

        fun fromParagraphs(paragraphs: List<String>, known: Map<String, Gender> = emptyMap()): ChapterContent {
            val clean = paragraphs.map { it.trim() }.filter { it.isNotEmpty() }
            val chunks = ArrayList<Chunk>()
            val attributor = Attributor(known)
            clean.forEachIndexed { p, text ->
                val parsed = DialogueParser.parse(text)
                val speakers = attributor.attribute(text, parsed.segments, parsed.unclosed)
                parsed.segments.forEachIndexed { k, seg ->
                    val part = text.substring(seg.start, seg.end)
                    for ((s, e) in SentenceSplitter.split(part)) {
                        chunks.add(Chunk(p, seg.start + s, seg.start + e, part.substring(s, e), speakers[k]))
                    }
                }
                // Text made only of symbols ("* * *") has no segment; keep it so the paragraph still has a chunk.
                if (parsed.segments.isEmpty()) chunks.add(Chunk(p, 0, text.length, text))
            }
            return ChapterContent(clean, chunks)
        }

        /** Chapters are stored on disk as one paragraph per line. */
        fun fromStoredText(text: String, known: Map<String, Gender> = emptyMap()): ChapterContent =
            fromParagraphs(text.split('\n'), known)
    }
}

/**
 * Splits a paragraph into pieces that are comfortable for the TTS model:
 * whole sentences, merged when very short, wrapped at clause breaks when very long.
 * Returns [start, end) ranges into the input, so nothing is ever rewritten.
 */
object SentenceSplitter {

    private val ABBREVIATIONS = setOf(
        "mr", "mrs", "ms", "dr", "prof", "sr", "jr", "st", "mt", "vs", "e.g", "i.e",
        "fig", "vol", "inc", "ltd", "co", "gen", "col", "lt", "capt", "sgt", "rev",
        "hon", "ave", "dept", "approx",
    )
    private const val TERMINALS = ".!?…"
    private const val CLOSERS = "\"'”’)]}»"
    private const val CLAUSE_BREAKS = ",;:—–"

    fun split(text: String, maxLen: Int = 200, minLen: Int = 30): List<Pair<Int, Int>> {
        val pieces = ArrayList<Pair<Int, Int>>()
        for ((s, e) in splitSentences(text)) wrapLong(text, s, e, maxLen, pieces)

        // Merge very short pieces into their neighbour: better prosody, fewer model calls.
        val out = ArrayList<Pair<Int, Int>>()
        var cur: Pair<Int, Int>? = null
        for (p in pieces) {
            val c = cur
            if (c == null) {
                cur = p
            } else if (c.second - c.first < minLen && p.second - c.first <= maxLen) {
                cur = c.first to p.second
            } else {
                out.add(c)
                cur = p
            }
        }
        cur?.let { out.add(it) }
        return out
    }

    private fun splitSentences(text: String): List<Pair<Int, Int>> {
        val result = ArrayList<Pair<Int, Int>>()
        val n = text.length
        var start = 0
        var i = 0
        while (i < n) {
            if (text[i] in TERMINALS) {
                var j = i + 1
                while (j < n && text[j] in TERMINALS) j++
                while (j < n && text[j] in CLOSERS) j++
                val endsHere = j >= n || text[j].isWhitespace()
                val abbreviation = text[i] == '.' && j == i + 1 && isAbbreviation(text, i)
                if (endsHere && !abbreviation) {
                    addTrimmed(text, start, j, result)
                    while (j < n && text[j].isWhitespace()) j++
                    start = j
                }
                i = j
            } else {
                i++
            }
        }
        addTrimmed(text, start, n, result)
        return result
    }

    private fun isAbbreviation(text: String, dot: Int): Boolean {
        var s = dot
        while (s > 0 && (text[s - 1].isLetter() || text[s - 1] == '.')) s--
        val token = text.substring(s, dot).lowercase()
        if (token.isEmpty()) return false
        if (token in ABBREVIATIONS) return true
        if (token.length == 1) return text[s].isUpperCase()            // initials: "J. K. Rowling"
        if (token.contains('.') && token.split('.').all { it.length == 1 }) return true   // "U.S."
        return false
    }

    private fun wrapLong(text: String, s: Int, e: Int, maxLen: Int, out: MutableList<Pair<Int, Int>>) {
        var start = s
        while (e - start > maxLen) {
            val limit = start + maxLen
            var cut = -1
            var k = limit
            while (k > start + maxLen / 2) {
                if (text[k - 1] in CLAUSE_BREAKS && text[k].isWhitespace()) { cut = k; break }
                k--
            }
            if (cut == -1) {
                k = limit
                while (k > start + 1) {
                    if (text[k].isWhitespace()) { cut = k; break }
                    k--
                }
            }
            if (cut == -1) cut = limit
            addTrimmed(text, start, cut, out)
            start = cut
            while (start < e && text[start].isWhitespace()) start++
        }
        addTrimmed(text, start, e, out)
    }

    private fun addTrimmed(text: String, from: Int, to: Int, out: MutableList<Pair<Int, Int>>) {
        var s = from
        var e = to
        while (s < e && text[s].isWhitespace()) s++
        while (e > s && text[e - 1].isWhitespace()) e--
        if (e > s) out.add(s to e)
    }
}
