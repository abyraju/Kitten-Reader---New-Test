package com.kittenml.kittentts.core

enum class Gender { MALE, FEMALE, UNKNOWN }

/** A stretch of one paragraph: either quoted speech or narration. */
class Segment(val start: Int, val end: Int, val dialogue: Boolean)

/** Splits a paragraph at double quotes. Straight (") and curly (“ ”) quotes are supported. */
object DialogueParser {

    class Result(val segments: List<Segment>, val unclosed: Boolean)

    fun parse(text: String): Result {
        val raw = ArrayList<Segment>()
        var inQuote = false
        var start = 0
        for (i in text.indices) {
            val c = text[i]
            when {
                !inQuote && (c == '“' || c == '"') -> {
                    raw.add(Segment(start, i, false)); start = i; inQuote = true
                }
                inQuote && c == '“' -> {            // new opening quote while one is still open
                    raw.add(Segment(start, i, true)); start = i
                }
                inQuote && (c == '”' || c == '"') -> {
                    raw.add(Segment(start, i + 1, true)); start = i + 1; inQuote = false
                }
            }
        }
        if (start < text.length) raw.add(Segment(start, text.length, inQuote))
        val kept = raw.filter { seg -> (seg.start until seg.end).any { text[it].isLetterOrDigit() } }
        return Result(kept, inQuote)
    }
}

/**
 * Works out who speaks each quoted segment from nearby speech tags
 * ("…," said Alice / he whispered / Alice asked, "…") and conversation flow.
 * Speaker keys: a character's last name token ("Alice", "Darcy"), "?male", "?female",
 * "?" (unknown), or null (the narrator, e.g. "I said").
 */
class Attributor(private val known: Map<String, Gender> = emptyMap()) {

    private val learned = HashMap<String, Gender>()
    private val lastByGender = HashMap<Gender, String>()
    private val recent = ArrayList<String>()          // most recent named speakers first
    private var previousParagraphHadDialogue = false
    private var previousUnclosed = false
    private var previousSpeaker: String? = null

    /** Returns one entry per segment: null for narration or narrator-voiced speech. */
    fun attribute(text: String, segments: List<Segment>, unclosed: Boolean): List<String?> {
        val result = arrayOfNulls<String>(segments.size)
        var paragraphSpeaker: String? = null
        var sawDialogue = false
        var first = true

        for ((k, seg) in segments.withIndex()) {
            if (!seg.dialogue) continue
            sawDialogue = true
            val before = segments.getOrNull(k - 1)?.takeIf { !it.dialogue }
            val after = segments.getOrNull(k + 1)?.takeIf { !it.dialogue }

            var speaker: String? = null
            var resolved = false

            // "Elizabeth looked up. “…”": the subject of the last narration sentence before the quote.
            val action = findActionSubject(before?.let { text.substring(it.start, it.end) })
            if (action != null && genderOf(action) != Gender.UNKNOWN) remember(action)

            val tag = findAfterTag(after?.let { text.substring(it.start, minOf(it.end, it.start + 90)) })
                ?: findBeforeTag(before?.let { text.substring(it.start, it.end) })
            if (tag != null) {
                resolved = true
                speaker = resolve(tag)
            }

            if (!resolved && action != null && genderOf(action) != Gender.UNKNOWN) {
                resolved = true
                speaker = action
            }

            if (!resolved) {
                speaker = when {
                    paragraphSpeaker != null -> paragraphSpeaker
                    first && previousUnclosed -> previousSpeaker
                    previousParagraphHadDialogue -> recent.getOrNull(1) ?: "?"
                    else -> "?"
                }
            }

            if (speaker != null) {
                paragraphSpeaker = speaker
                if (!speaker.startsWith("?")) remember(speaker)
            }
            result[k] = speaker
            first = false
        }

        previousParagraphHadDialogue = sawDialogue
        previousUnclosed = unclosed
        previousSpeaker = paragraphSpeaker
        return result.toList()
    }

    // ─── tag detection ───────────────────────────────────────────────────────

    private class Tag(val name: String?, val pronoun: String?)

    private fun findAfterTag(s: String?): Tag? {
        if (s == null) return null
        AFTER_A.find(s)?.let { return tagOf(it.groups["n"]?.value, it.groups["p"]?.value) }
        AFTER_B.find(s)?.let { return tagOf(it.groups["n"]?.value, it.groups["p"]?.value) }
        AFTER_C.find(s)?.let { return Tag(null, if (it.groups["r"]!!.value.lowercase() in MALE_NOUN) "he" else "she") }
        return null
    }

    private fun findBeforeTag(s: String?): Tag? {
        if (s == null) return null
        val m = BEFORE.find(s.trimEnd()) ?: return null
        return tagOf(m.groups["n"]?.value, m.groups["p"]?.value)
    }

    private fun findActionSubject(s: String?): String? {
        if (s == null) return null
        val body = s.trim().trimEnd('.', '!', '?', ' ', ',', ':')
        val lastSentence = body.substring(maxOf(body.lastIndexOfAny(charArrayOf('.', '!', '?')) + 1, 0)).trimStart()
        val m = ACTION.find(lastSentence)?.takeIf { it.range.first == 0 } ?: return null
        val name = m.groups["n"]!!.value
        if (name.lowercase() in PRONOUNS || name.lowercase() in STOP) return null
        return keyOf(name).also { k -> titleGender(name).let { g -> if (g != Gender.UNKNOWN) learned[k] = g } }
    }

    private fun tagOf(name: String?, pronoun: String?): Tag? {
        if (name != null) {
            val low = name.lowercase()
            if (low in PRONOUNS) return Tag(null, low)
            if (low in STOP) return null
            return Tag(name, null)
        }
        return pronoun?.let { Tag(null, it.lowercase()) }
    }

    private fun resolve(tag: Tag): String? {
        if (tag.name != null) {
            val key = keyOf(tag.name)
            val titleGender = titleGender(tag.name)
            if (titleGender != Gender.UNKNOWN) learned[key] = titleGender
            return key
        }
        return when (tag.pronoun) {
            "he" -> lastByGender[Gender.MALE] ?: "?male"
            "she" -> lastByGender[Gender.FEMALE] ?: "?female"
            "i", "we" -> null
            else -> "?"
        }
    }

    private fun remember(key: String) {
        recent.remove(key)
        recent.add(0, key)
        if (recent.size > 6) recent.removeAt(recent.lastIndex)
        val g = genderOf(key)
        if (g != Gender.UNKNOWN) lastByGender[g] = key
    }

    private fun genderOf(key: String): Gender =
        known[key] ?: learned[key] ?: NameGenders.guess(key)

    companion object {
        private const val TITLES = "Mr|Mrs|Ms|Miss|Dr|Sir|Lady|Lord|Captain|Professor|Madame|Mademoiselle|Monsieur|Uncle|Aunt|Father|Mother"
        private const val NAME = "(?:(?:$TITLES)\\.?\\s+)?[A-Z][\\p{L}]+(?:['’-][A-Z]?[\\p{L}]+)?"
        private const val VERBS = "said|asked|replied|cried|shouted|whispered|answered|muttered|murmured|exclaimed|called|added|" +
            "continued|began|demanded|snapped|sighed|laughed|yelled|responded|insisted|suggested|declared|remarked|observed|" +
            "inquired|retorted|growled|sobbed|gasped|interrupted|explained|warned|announced|stammered|groaned|breathed|urged|" +
            "pleaded|protested|agreed|admitted|offered|cheered|squealed|shrieked|bellowed|roared|hissed|mumbled|whined|teased|mused|" +
            "returned|rejoined|resumed|cried out|spoke"
        private const val PRON = "(?i:he|she|they|i|we)"

        private val AFTER_A = Regex("^\\s*[,.;:]?\\s*(?:(?<n>$NAME)|(?<p>$PRON))\\s+(?:\\p{L}+ly\\s+)?(?i:$VERBS)\\b")
        private val AFTER_B = Regex("^\\s*[,.;:]?\\s*(?i:$VERBS)\\s+(?:(?<n>$NAME)|(?<p>(?i:he|she)))\\b")
        private val AFTER_C = Regex("^\\s*[,.;:]?\\s*(?i:$VERBS)\\s+(?i:his|her|the|a)\\s+(?<r>(?i:wife|husband|mother|father|sister|brother|lady|gentleman|man|woman|girl|boy|king|queen|son|daughter))\\b")
        private val ACTION = Regex("(?<n>$NAME)\\s+\\p{L}+")
        private val MALE_NOUN = setOf("husband", "father", "brother", "gentleman", "man", "boy", "king", "son")
        private val BEFORE = Regex("(?:(?<n>$NAME)|(?<p>$PRON))\\s+(?:\\p{L}+\\s+){0,3}?(?i:$VERBS)\\b[^.!?]{0,30}$")

        private val PRONOUNS = setOf("he", "she", "they", "i", "we", "it", "you")
        private val STOP = setOf(
            "the", "a", "an", "and", "but", "then", "there", "this", "that", "his", "her", "their", "suddenly",
            "when", "while", "as", "so", "now", "yes", "no", "oh", "well", "after", "before", "once", "later",
            "meanwhile", "finally", "again", "still", "just", "even", "only", "soon", "at", "in", "on", "with",
        )
        private val TITLE_MALE = setOf("mr", "sir", "lord", "uncle", "father", "monsieur")
        private val TITLE_FEMALE = setOf("mrs", "ms", "miss", "lady", "aunt", "mother", "madame", "mademoiselle")

        /** "Elizabeth Bennet" → "Bennet"; gendered titles are kept so "Mr. Bennet" and "Mrs. Bennet" differ. */
        fun keyOf(name: String): String {
            val parts = name.trim().split(Regex("\\s+"))
            val last = parts.last().removeSuffix("'s").removeSuffix("’s")
            if (parts.size < 2) return last
            val title = parts.first().trimEnd('.')
            return if (title.lowercase() in TITLE_MALE + TITLE_FEMALE) "$title. $last" else last
        }

        fun titleGender(name: String): Gender {
            val first = name.trim().split(Regex("\\s+")).first().trimEnd('.').lowercase()
            return when (first) {
                in TITLE_MALE -> Gender.MALE
                in TITLE_FEMALE -> Gender.FEMALE
                else -> Gender.UNKNOWN
            }
        }
    }
}
