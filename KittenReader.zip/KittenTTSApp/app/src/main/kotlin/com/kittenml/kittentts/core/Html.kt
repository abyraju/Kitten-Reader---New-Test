package com.kittenml.kittentts.core

/** Minimal, dependency-free XHTML → plain text conversion for EPUB chapters. */
object HtmlText {

    private val FLAGS = setOf(RegexOption.DOT_MATCHES_ALL, RegexOption.IGNORE_CASE)
    private val COMMENT = Regex("<!--.*?-->", RegexOption.DOT_MATCHES_ALL)
    private val SKIPPED = Regex("<(script|style|head|svg|math)\\b[^>]*>.*?</\\1\\s*>", FLAGS)
    private val BR = Regex("<br\\s*/?>", RegexOption.IGNORE_CASE)
    private val BLOCK = Regex(
        "</?(p|div|h[1-6]|li|ul|ol|tr|table|blockquote|section|article|pre|dt|dd|" +
            "figure|figcaption|header|footer|aside|hr)\\b[^>]*>",
        RegexOption.IGNORE_CASE,
    )
    private val TAG = Regex("<[^>]*>")
    private val ENTITY = Regex("&(#[xX][0-9a-fA-F]+|#[0-9]+|[a-zA-Z][a-zA-Z0-9]*);")
    private val WHITESPACE = Regex("\\s+")
    private val INVISIBLE = Regex("[\\u200B\\u200C\\u200D\\uFEFF\\u00AD]")
    private val HEADING = Regex("<h[1-3]\\b[^>]*>(.*?)</h[1-3]\\s*>", FLAGS)

    private val NAMED = mapOf(
        "amp" to "&", "lt" to "<", "gt" to ">", "quot" to "\"", "apos" to "'", "nbsp" to " ",
        "mdash" to "—", "ndash" to "–", "hellip" to "…", "lsquo" to "‘", "rsquo" to "’",
        "ldquo" to "“", "rdquo" to "”", "laquo" to "«", "raquo" to "»", "copy" to "©",
        "eacute" to "é", "egrave" to "è", "agrave" to "à", "acirc" to "â", "ccedil" to "ç",
        "ecirc" to "ê", "icirc" to "î", "ocirc" to "ô", "ucirc" to "û", "uuml" to "ü",
        "ouml" to "ö", "auml" to "ä", "szlig" to "ß", "ntilde" to "ñ", "iacute" to "í",
        "oacute" to "ó", "uacute" to "ú", "aacute" to "á", "middot" to "·", "bull" to "•",
        "times" to "×", "deg" to "°", "frac12" to "½", "thinsp" to " ", "ensp" to " ", "emsp" to " ",
    )

    /** Converts markup to plain paragraphs (blank ones dropped, whitespace collapsed). */
    fun toParagraphs(html: String): List<String> {
        var s = COMMENT.replace(html, "")
        s = SKIPPED.replace(s, "")
        s = BR.replace(s, "\n")
        s = BLOCK.replace(s, "\n")
        s = TAG.replace(s, "")
        s = decodeEntities(s)
        return s.split('\n').map { collapse(it) }.filter { it.isNotEmpty() }
    }

    /** Text of the first h1–h3 heading, or null. */
    fun firstHeading(html: String): String? {
        val raw = HEADING.find(html)?.groupValues?.get(1) ?: return null
        val text = toParagraphs(raw).joinToString(" ").trim()
        return text.takeIf { it.isNotEmpty() }?.take(90)
    }

    fun decodeEntities(s: String): String {
        if (!s.contains('&')) return s
        return ENTITY.replace(s) { m ->
            val g = m.groupValues[1]
            val decoded: String? = when {
                g.startsWith("#x") || g.startsWith("#X") -> codePoint(g.substring(2).toIntOrNull(16))
                g.startsWith("#") -> codePoint(g.substring(1).toIntOrNull())
                else -> NAMED[g]
            }
            decoded ?: m.value
        }
    }

    private fun codePoint(cp: Int?): String? =
        cp?.takeIf { it in 1..0x10FFFF && it !in 0xD800..0xDFFF }?.let { String(Character.toChars(it)) }

    private fun collapse(line: String): String =
        INVISIBLE.replace(line, "").replace(' ', ' ').replace(WHITESPACE, " ").trim()
}
