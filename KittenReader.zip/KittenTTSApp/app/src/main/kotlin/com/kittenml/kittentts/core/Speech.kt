package com.kittenml.kittentts.core

/**
 * Prepares text for the voice model and decides how long to pause after each piece.
 * The displayed text is never changed; this only affects what is spoken.
 */
object SpeechText {

    private val DIGIT_RANGE = Regex("(\\d)\\s*[–—]\\s*(\\d)")
    private val FOOTNOTE = Regex("\\[\\d+]")
    private val DASH = Regex("\\s*[—–]+\\s*|\\s+-{1,2}\\s+")
    private val ELLIPSIS = Regex("\\s*(\\.{2,}|…)\\s*")
    private val DOUBLE_QUOTES = Regex("[“”\"«»„]")
    private val EDGE_APOSTROPHE = Regex("(?<![\\p{L}\\p{N}])'|'(?![\\p{L}\\p{N}])")
    private val BRACKETS = Regex("[()\\[\\]{}]")
    private val JUNK = Regex("[*_#~^|\\\\<>=]")
    private val SLASH = Regex("\\s*/\\s*")
    private val SPACE_BEFORE_PUNCT = Regex("\\s+([,.;:!?])")
    private val COMMA_RUN = Regex("(,\\s*){2,}")
    private val COMMA_THEN_END = Regex("[,;:]\\s*([.!?])")
    private val LEADING_PUNCT = Regex("^[\\s,;:.]+")
    private val SPACES = Regex("\\s+")
    private val CHAPTER_ROMAN = Regex("^(chapter|part|book|act|section|volume)\\s+([ivxlcdm]+)\\b", RegexOption.IGNORE_CASE)
    private const val CLOSERS = "\"'”’)]}»“‘"

    fun normalize(raw: String): String {
        var s = raw.replace('’', '\'').replace('‘', '\'').replace(' ', ' ')
        s = deShout(s)
        s = romanChapter(s)
        s = DIGIT_RANGE.replace(s, "$1 to $2")
        s = FOOTNOTE.replace(s, "")
        s = DOUBLE_QUOTES.replace(s, "")
        s = EDGE_APOSTROPHE.replace(s, "")
        s = DASH.replace(s, ", ")
        s = ELLIPSIS.replace(s) { m -> if (m.range.last >= s.length - 1) "." else ", " }
        s = BRACKETS.replace(s, ", ")
        s = JUNK.replace(s, " ")
        s = SLASH.replace(s, " ")
        s = SPACES.replace(s, " ").trim()
        s = SPACE_BEFORE_PUNCT.replace(s, "$1")
        s = COMMA_RUN.replace(s, ", ")
        s = COMMA_THEN_END.replace(s, "$1")
        s = LEADING_PUNCT.replace(s, "")
        s = s.trimEnd(',', ' ')
        // Give lines that end without punctuation (headings, list items) a falling, finished tone.
        if (s.isNotEmpty() && s.last().isLetterOrDigit()) s += "."
        return s
    }

    /** "CHAPTER ONE" → "Chapter One" when nearly everything is capitals (leaves "NASA said…" alone). */
    private fun deShout(s: String): String {
        val letters = s.count { it.isLetter() }
        if (letters < 4) return s
        val upper = s.count { it.isUpperCase() }
        if (upper.toFloat() / letters < 0.8f) return s
        return s.split(' ').joinToString(" ") { w ->
            if (w.length <= 1) w else w.lowercase().replaceFirstChar { it.uppercase() }
        }
    }

    /** "Chapter XII" → "Chapter 12" so the voice says a number instead of spelling letters. */
    private fun romanChapter(s: String): String {
        val m = CHAPTER_ROMAN.find(s) ?: return s
        val n = romanToInt(m.groupValues[2]) ?: return s
        return s.replaceRange(m.groups[2]!!.range, n.toString())
    }

    internal fun romanToInt(r: String): Int? {
        val v = mapOf('i' to 1, 'v' to 5, 'x' to 10, 'l' to 50, 'c' to 100, 'd' to 500, 'm' to 1000)
        var total = 0
        var prev = 0
        for (ch in r.lowercase().reversed()) {
            val x = v[ch] ?: return null
            if (x < prev) total -= x else { total += x; prev = x }
        }
        return total.takeIf { it in 1..3999 }
    }

    // ─── Pauses ──────────────────────────────────────────────────────────────

    /** Last character that carries meaning, ignoring closing quotes/brackets. */
    internal fun lastMeaningful(text: String): Char? =
        text.trimEnd().trimEnd { it in CLOSERS || it.isWhitespace() }.lastOrNull()

    /** A short line with no closing punctuation: a title, chapter heading, etc. */
    internal fun isHeading(paragraph: String): Boolean {
        val t = paragraph.trim()
        if (t.isEmpty() || t.length > 80) return false
        val last = lastMeaningful(t) ?: return false
        return last.isLetterOrDigit()
    }

    /** Silence (ms, at normal speed and default pause setting) to insert after chunk [index]. */
    fun pauseMs(content: ChapterContent, index: Int): Int {
        val c = content.chunks[index]
        val text = c.text.trimEnd()
        var ms = when {
            text.endsWith("…") || text.endsWith("...") -> 450
            else -> when (lastMeaningful(text)) {
                '.' -> 320
                '!', '?' -> 380
                ':', ';' -> 240
                ',', '—', '–', '-' -> 160
                else -> 260
            }
        }
        // A narration tag that continues the sentence ("…!" he cried.) follows with only a short beat.
        val next = content.chunks.getOrNull(index + 1)
        val continues = next != null && next.paragraph == c.paragraph &&
            next.text.firstOrNull { it.isLetter() }?.isLowerCase() == true
        if (continues) ms = minOf(ms, 150)
        val endsParagraph = content.chunks.getOrNull(index + 1)?.paragraph != c.paragraph
        if (endsParagraph) {
            ms = if (isHeading(content.paragraphs[c.paragraph])) 1100 else maxOf(ms, 700)
        }
        return ms
    }
}
