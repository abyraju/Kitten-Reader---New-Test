package com.kittenml.kittentts.core

import java.nio.ByteBuffer
import java.nio.charset.CharacterCodingException
import java.nio.charset.CodingErrorAction

/** Turns a .txt file into chapters: detects encoding, un-wraps hard-wrapped lines, finds headings. */
object TxtImporter {

    private const val FRONT_MATTER_MIN = 500
    private const val SECTION_TARGET = 12_000
    private const val SECTION_MIN_TAIL = 3_000
    private const val MAX_JOINED_PARAGRAPH = 3_000

    private val NUMBERED_HEADING = Regex(
        "^(chapter|part|book|section|act)\\s+([0-9]+|[ivxlcdm]+|one|two|three|four|five|six|seven|eight|nine|ten|" +
            "eleven|twelve|thirteen|fourteen|fifteen|sixteen|seventeen|eighteen|nineteen|twenty|first|second|third)\\b.*$",
        RegexOption.IGNORE_CASE,
    )
    private val NAMED_HEADING = Regex(
        "^(prologue|epilogue|preface|introduction|foreword|afterword)\\b.*$",
        RegexOption.IGNORE_CASE,
    )
    private val GUTENBERG_START = Regex("\\*\\*\\* ?START OF (THE|THIS) PROJECT GUTENBERG EBOOK.*?\\*\\*\\*", RegexOption.IGNORE_CASE)
    private val GUTENBERG_END = Regex("\\*\\*\\* ?END OF (THE|THIS) PROJECT GUTENBERG EBOOK", RegexOption.IGNORE_CASE)
    private val G_TITLE = Regex("(?m)^Title:\\s*(.+?)\\s*$")
    private val G_AUTHOR = Regex("(?m)^Author:\\s*(.+?)\\s*$")
    private val BLANK_LINES = Regex("\\n[ \\t]*\\n+")
    private val WHITESPACE = Regex("\\s+")

    fun parse(bytes: ByteArray, fallbackTitle: String): ParsedBook {
        val text = decode(bytes).replace("\r\n", "\n").replace('\r', '\n')

        var title = fallbackTitle
        var author: String? = null
        var body = text
        val start = GUTENBERG_START.find(text)
        if (start != null) {
            val header = text.substring(0, start.range.first)
            G_TITLE.find(header)?.groupValues?.get(1)?.let { title = it }
            author = G_AUTHOR.find(header)?.groupValues?.get(1)
            body = text.substring(start.range.last + 1)
            GUTENBERG_END.find(body)?.let { body = body.substring(0, it.range.first) }
        }

        val paragraphs = toParagraphs(body)
        require(paragraphs.isNotEmpty()) { "This text file is empty" }
        return ParsedBook(title, author, splitChapters(paragraphs))
    }

    internal fun decode(bytes: ByteArray): String {
        if (bytes.size >= 2 && bytes[0] == 0xFF.toByte() && bytes[1] == 0xFE.toByte()) {
            return String(bytes, 2, bytes.size - 2, Charsets.UTF_16LE)
        }
        if (bytes.size >= 2 && bytes[0] == 0xFE.toByte() && bytes[1] == 0xFF.toByte()) {
            return String(bytes, 2, bytes.size - 2, Charsets.UTF_16BE)
        }
        val off = if (bytes.size >= 3 && bytes[0] == 0xEF.toByte() && bytes[1] == 0xBB.toByte() && bytes[2] == 0xBF.toByte()) 3 else 0
        return try {
            Charsets.UTF_8.newDecoder()
                .onMalformedInput(CodingErrorAction.REPORT)
                .onUnmappableCharacter(CodingErrorAction.REPORT)
                .decode(ByteBuffer.wrap(bytes, off, bytes.size - off))
                .toString()
        } catch (_: CharacterCodingException) {
            String(bytes, off, bytes.size - off, charset("windows-1252"))
        }
    }

    internal fun toParagraphs(text: String): List<String> {
        val out = ArrayList<String>()
        for (block in text.split(BLANK_LINES)) {
            val lines = block.split('\n').map { it.trim() }.filter { it.isNotEmpty() }
            if (lines.isEmpty()) continue
            if (lines.size == 1) {
                out.add(collapse(lines[0]))
                continue
            }
            val avg = lines.sumOf { it.length } / lines.size
            val max = lines.maxOf { it.length }
            val total = lines.sumOf { it.length }
            if (avg >= 45 && max <= 140 && total <= MAX_JOINED_PARAGRAPH) {
                out.add(collapse(lines.joinToString(" ")))     // hard-wrapped prose
            } else {
                lines.forEach { out.add(collapse(it)) }         // verse, dialogue, one-line paragraphs
            }
        }
        return out
    }

    private fun collapse(s: String) = s.replace(WHITESPACE, " ").trim()

    private fun isHeading(p: String) =
        p.length <= 80 && (NUMBERED_HEADING.matches(p) || NAMED_HEADING.matches(p))

    internal fun splitChapters(paragraphs: List<String>): List<ParsedChapter> {
        val headingIdx = paragraphs.indices.filter { isHeading(paragraphs[it]) }
        return if (headingIdx.size >= 3) splitAtHeadings(paragraphs, headingIdx) else splitBySize(paragraphs)
    }

    private fun splitAtHeadings(paragraphs: List<String>, headings: List<Int>): List<ParsedChapter> {
        val chapters = ArrayList<ParsedChapter>()
        val front = paragraphs.subList(0, headings[0])
        val frontChars = front.sumOf { it.length }
        if (frontChars >= FRONT_MATTER_MIN) chapters.add(ParsedChapter("Front matter", front))

        for ((n, h) in headings.withIndex()) {
            val end = if (n + 1 < headings.size) headings[n + 1] else paragraphs.size
            val body = ArrayList<String>()
            if (n == 0 && frontChars in 1 until FRONT_MATTER_MIN) body.addAll(front)
            body.addAll(paragraphs.subList(h, end))
            chapters.add(ParsedChapter(paragraphs[h].take(90), body))
        }
        return chapters
    }

    private fun splitBySize(paragraphs: List<String>): List<ParsedChapter> {
        val groups = ArrayList<MutableList<String>>()
        var cur = ArrayList<String>()
        var chars = 0
        for (p in paragraphs) {
            cur.add(p)
            chars += p.length
            if (chars >= SECTION_TARGET) {
                groups.add(cur)
                cur = ArrayList()
                chars = 0
            }
        }
        if (cur.isNotEmpty()) {
            if (groups.isNotEmpty() && chars < SECTION_MIN_TAIL) groups.last().addAll(cur) else groups.add(cur)
        }
        return if (groups.size == 1) listOf(ParsedChapter("Text", groups[0]))
        else groups.mapIndexed { i, g -> ParsedChapter("Part ${i + 1}", g) }
    }
}
