package com.kittenml.kittentts.core

/** One speaking character found in a book. [voice] is the user's override (null = automatic). */
data class CastMember(val name: String, val gender: Gender, val lines: Int, val voice: String?)

object NameGenders {
    private val FEMALE = (
        "mary patricia jennifer linda elizabeth barbara susan jessica sarah karen nancy lisa betty margaret sandra ashley " +
        "kimberly emily donna michelle dorothy carol amanda melissa deborah stephanie rebecca sharon laura cynthia kathleen " +
        "amy angela shirley anna brenda pamela nicole emma helen samantha katherine christine debra rachel carolyn janet " +
        "catherine maria heather diane olivia julie joyce victoria ruth virginia lauren kelly christina joan evelyn judith " +
        "megan andrea cheryl hannah jacqueline martha gloria teresa ann sara madison frances kathryn janice jean abigail " +
        "alice judy sophia grace denise amber doris marilyn danielle beverly isabella theresa diana natalie brittany " +
        "charlotte marie kayla alexis lori jane lucy anne eleanor georgiana lydia kitty mina lucia hermione ginny luna " +
        "molly lily fleur cho bella rosie kiki rose violet daisy ivy eva ella mia zoe chloe nora clara edith agnes sophie " +
        "annabelle beatrice cordelia cecilia dorothea harriet isabel josephine matilda penelope portia viola ophelia " +
        "juliet desdemona cressida elinor marianne fanny emmeline eliza esther rosalind celia hero beatrix daenerys arya " +
        "sansa cersei catelyn brienne buffy willow tara xena scarlett melanie prissy belle ariel jasmine " +
        "elsa anna katniss primrose effie johanna tris trinity leia padme rey"
        ).split(' ').toSet()

    private val MALE = (
        "james john robert michael william david richard joseph thomas charles christopher daniel matthew anthony mark " +
        "donald steven paul andrew joshua kenneth kevin brian george timothy ronald edward jason jeffrey ryan jacob gary " +
        "nicholas eric jonathan stephen larry justin scott brandon benjamin samuel gregory alexander frank patrick raymond " +
        "jack dennis jerry tyler aaron jose adam nathan henry douglas zachary peter kyle walter ethan jeremy harold " +
        "keith christian roger noah gerald carl terry sean austin arthur lawrence jesse dylan bryan joe jordan billy " +
        "bruce albert willie gabriel logan alan juan wayne roy ralph randy eugene vincent russell elijah louis bobby " +
        "philip johnny harry ron ronald neville draco severus albus sirius remus hagrid dudley vernon fred george percy " +
        "bill charlie oliver sherlock watson holmes darcy bingley wickham collins edmund fitzwilliam heathcliff linton " +
        "hareton rochester gatsby nick tom holden atticus jem finch huck tom sawyer ahab ishmael pip joe jaggers " +
        "scrooge marley cratchit fezziwig hamlet horatio laertes polonius claudius macbeth banquo duncan lear edgar " +
        "romeo mercutio benvolio tybalt othello iago cassio prospero caliban ferdinand bilbo frodo sam gandalf aragorn " +
        "legolas gimli boromir gollum pippin merry theoden elrond jasper bruno hugo leo max luke han lando anakin obi " +
        "jon robb bran ned eddard joffrey tywin jaime theon stannis harvey rick morty homer bart marge ben dean sam " +
        "ivan alyosha dmitri raskolnikov porfiry svidrigailov levin vronsky pierre andrei nikolai boris"
        ).split(' ').toSet()

    fun guess(name: String): Gender {
        val n = name.lowercase().trim()
        return when {
            n in FEMALE && n !in MALE -> Gender.FEMALE
            n in MALE && n !in FEMALE -> Gender.MALE
            else -> Gender.UNKNOWN
        }
    }
}

/** Finds the speaking characters of a book. */
object CastBuilder {

    private const val MIN_LINES = 2
    private const val MAX_CHARACTERS = 12
    private val HE = setOf("he", "his", "him", "himself")
    private val SHE = setOf("she", "her", "hers", "herself")

    fun discover(chapters: List<List<String>>): List<CastMember> {
        val counts = HashMap<String, Int>()
        val att = Attributor()
        for (paras in chapters) {
            for (p in paras) {
                val parsed = DialogueParser.parse(p)
                val speakers = att.attribute(p, parsed.segments, parsed.unclosed)
                for ((i, s) in speakers.withIndex()) {
                    if (parsed.segments[i].dialogue && s != null && !s.startsWith("?")) counts.merge(s, 1, Int::plus)
                }
            }
        }
        val top = counts.entries.filter { it.value >= MIN_LINES }
            .sortedByDescending { it.value }.take(MAX_CHARACTERS)
        if (top.isEmpty()) return emptyList()

        val votes = pronounVotes(chapters, top.map { it.key }.toSet())
        return top.map { (name, n) ->
            var g = Attributor.titleGender(name).takeIf { it != Gender.UNKNOWN } ?: NameGenders.guess(name.substringAfterLast(" "))
            if (g == Gender.UNKNOWN) {
                val (m, f) = votes[name] ?: (0 to 0)
                g = when {
                    m >= f + 2 -> Gender.MALE
                    f >= m + 2 -> Gender.FEMALE
                    else -> Gender.UNKNOWN
                }
            }
            CastMember(name, g, n, null)
        }
    }

    /** For each name, counts whether "he/his…" or "she/her…" follows it in the same sentence. */
    private fun pronounVotes(chapters: List<List<String>>, names: Set<String>): Map<String, Pair<Int, Int>> {
        val out = HashMap<String, IntArray>()
        val rx = Regex("\\b(${names.joinToString("|") { Regex.escape(it) }})\\b([^.!?\"“”\\n]{0,70})")
        val word = Regex("\\p{L}+")
        for (paras in chapters) for (p in paras) {
            for (m in rx.findAll(p)) {
                val first = word.findAll(m.groupValues[2]).map { it.value.lowercase() }.firstOrNull { it in HE || it in SHE } ?: continue
                val arr = out.getOrPut(m.groupValues[1]) { IntArray(2) }
                if (first in HE) arr[0]++ else arr[1]++
            }
        }
        return out.mapValues { it.value[0] to it.value[1] }
    }
}

/** Chooses which model voice speaks for each character. */
object CastVoices {

    fun voiceGender(voice: String): Gender {
        val v = voice.lowercase()
        return when {
            v.endsWith("-f") || v.endsWith("_f") || v.contains("female") -> Gender.FEMALE
            v.endsWith("-m") || v.endsWith("_m") || v.contains("male") -> Gender.MALE
            else -> NameGenders.guess(v.substringAfterLast('-').ifEmpty { v })
        }
    }

    private fun pool(voices: List<String>, narrator: String?) =
        voices.filter { it != narrator }.ifEmpty { voices }

    /** Character name → voice. Overrides win; others get gender-matched voices, cycling when they run out. */
    fun resolve(characters: List<CastMember>, voices: List<String>, narrator: String?): Map<String, String> {
        if (voices.isEmpty()) return emptyMap()
        val pool = pool(voices, narrator)
        val male = pool.filter { voiceGender(it) == Gender.MALE }
        val female = pool.filter { voiceGender(it) == Gender.FEMALE }
        val counters = HashMap<Gender, Int>()
        val out = LinkedHashMap<String, String>()
        for (c in characters.sortedByDescending { it.lines }) {
            val override = c.voice?.takeIf { it in voices }
            if (override != null) { out[c.name] = override; continue }
            val list = when (c.gender) {
                Gender.MALE -> male.ifEmpty { pool }
                Gender.FEMALE -> female.ifEmpty { pool }
                Gender.UNKNOWN -> pool
            }
            val i = counters.getOrDefault(c.gender, 0)
            counters[c.gender] = i + 1
            out[c.name] = list[i % list.size]
        }
        return out
    }

    fun voiceFor(speaker: String?, assignments: Map<String, String>, narrator: String?, voices: List<String>): String? {
        if (speaker == null) return narrator
        assignments[speaker]?.let { return it }
        val pool = pool(voices, narrator)
        return when (speaker) {
            "?male" -> pool.firstOrNull { voiceGender(it) == Gender.MALE } ?: narrator
            "?female" -> pool.firstOrNull { voiceGender(it) == Gender.FEMALE } ?: narrator
            else -> narrator
        }
    }
}
