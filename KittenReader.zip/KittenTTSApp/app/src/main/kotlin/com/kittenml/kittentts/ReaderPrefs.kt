package com.kittenml.kittentts

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** User settings shared by the UI and the reading service. */
object ReaderPrefs {
    private lateinit var prefs: SharedPreferences

    private val _voice = MutableStateFlow<String?>(null)
    val voice: StateFlow<String?> = _voice.asStateFlow()

    private val _speed = MutableStateFlow(1.0f)
    val speed: StateFlow<Float> = _speed.asStateFlow()

    private val _fontScale = MutableStateFlow(1.0f)
    val fontScale: StateFlow<Float> = _fontScale.asStateFlow()

    fun init(context: Context) {
        if (::prefs.isInitialized) return
        prefs = context.getSharedPreferences("settings", Context.MODE_PRIVATE)
        _voice.value = prefs.getString("voice", null)
        _speed.value = prefs.getFloat("speed", 1.0f)
        _fontScale.value = prefs.getFloat("font", 1.0f)
    }

    fun setVoice(v: String) { _voice.value = v; prefs.edit().putString("voice", v).apply() }
    fun setSpeed(s: Float) { _speed.value = s; prefs.edit().putFloat("speed", s).apply() }
    fun setFontScale(f: Float) { _fontScale.value = f; prefs.edit().putFloat("font", f).apply() }

    /** The saved voice if it still exists, otherwise the first available one. */
    fun effectiveVoice(available: List<String>): String? =
        _voice.value?.takeIf { it in available } ?: available.firstOrNull()
}
