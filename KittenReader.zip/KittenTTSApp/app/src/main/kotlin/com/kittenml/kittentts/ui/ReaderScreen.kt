package com.kittenml.kittentts.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.DragInteraction
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kittenml.kittentts.BookStore
import com.kittenml.kittentts.EngineState
import com.kittenml.kittentts.R
import com.kittenml.kittentts.ReaderPrefs
import com.kittenml.kittentts.ReaderService
import com.kittenml.kittentts.TtsRuntime
import com.kittenml.kittentts.core.ChapterContent
import kotlin.math.roundToInt

private enum class Dialog { None, Chapters, Voice, Sleep }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReaderScreen(bookId: String, onBack: () -> Unit) {
    val s by ReaderService.state.collectAsState()
    val engine by TtsRuntime.state.collectAsState()
    var dialog by remember { mutableStateOf(Dialog.None) }
    val fontScale by ReaderPrefs.fontScale.collectAsState()

    val ready = s.bookId == bookId
    val listState = rememberLazyListState()
    var follow by remember { mutableStateOf(true) }

    // Stop following the audio once the reader scrolls manually.
    LaunchedEffect(listState) {
        listState.interactionSource.interactions.collect { if (it is DragInteraction.Start) follow = false }
    }

    val currentParagraph = s.content.chunks.getOrNull(s.chunk)?.paragraph ?: 0
    LaunchedEffect(s.chapterIndex, currentParagraph, follow, s.content) {
        if (follow && s.content.paragraphs.isNotEmpty()) {
            listState.animateScrollToItem(currentParagraph.coerceAtMost(s.content.paragraphs.lastIndex))
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(s.bookTitle.ifBlank { BookStore.get(bookId)?.title.orEmpty() }, maxLines = 1, overflow = TextOverflow.Ellipsis,
                            style = MaterialTheme.typography.titleMedium)
                        Text(s.chapterTitle, maxLines = 1, overflow = TextOverflow.Ellipsis,
                            style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                },
                navigationIcon = { IconButton(onClick = onBack) { Icon(painterResource(R.drawable.ic_back), "Back") } },
                actions = {
                    IconButton(onClick = { dialog = Dialog.Chapters }) { Icon(painterResource(R.drawable.ic_list), "Chapters") }
                    IconButton(onClick = { dialog = Dialog.Sleep }) { Icon(painterResource(R.drawable.ic_timer), "Sleep timer") }
                    IconButton(onClick = { dialog = Dialog.Voice }) { Icon(painterResource(R.drawable.ic_tune), "Voice and text settings") }
                },
            )
        },
        bottomBar = {
            Surface(tonalElevation = 3.dp) {
                Controls(s.chunk, s.content, s.playing, s.buffering, engine, ready, s.error, s.sleepEndsAt)
            }
        },
    ) { padding ->
        Box(Modifier.padding(padding).fillMaxSize()) {
            if (!ready) {
                LinearProgressIndicator(Modifier.fillMaxWidth())
            } else {
                val current = s.content.chunks.getOrNull(s.chunk)
                LazyColumn(
                    state = listState,
                    contentPadding = PaddingValues(horizontal = 20.dp, vertical = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                    modifier = Modifier.fillMaxSize(),
                ) {
                    itemsIndexed(s.content.paragraphs) { idx, text ->
                        Paragraph(
                            text = text,
                            highlight = current?.takeIf { it.paragraph == idx }?.let { it.start until it.end },
                            fontScale = fontScale,
                            onTapOffset = { off ->
                                val chunks = s.content.chunks
                                val i = chunks.indexOfFirst { it.paragraph == idx && off >= it.start && off < it.end }
                                    .takeIf { it >= 0 } ?: s.content.firstChunkInParagraph[idx]
                                if (i >= 0) { follow = true; ReaderService.seek(s.chapterIndex, i) }
                            },
                        )
                    }
                }
                if (!follow && s.playing) {
                    FilledTonalButton(
                        onClick = { follow = true },
                        modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 12.dp),
                    ) { Text("Jump to current sentence") }
                }
            }
        }
    }

    when (dialog) {
        Dialog.Chapters -> ChapterDialog(bookId, s.chapterIndex, onPick = { follow = true; ReaderService.seek(it, 0); dialog = Dialog.None }, onDismiss = { dialog = Dialog.None })
        Dialog.Voice -> VoiceDialog(onDismiss = { dialog = Dialog.None })
        Dialog.Sleep -> SleepDialog(s.sleepEndsAt != null, onPick = { ReaderService.setSleepTimer(it); dialog = Dialog.None }, onDismiss = { dialog = Dialog.None })
        Dialog.None -> Unit
    }
}

@Composable
private fun Paragraph(text: String, highlight: IntRange?, fontScale: Float, onTapOffset: (Int) -> Unit) {
    var layout by remember { mutableStateOf<TextLayoutResult?>(null) }
    val hl = MaterialTheme.colorScheme.primaryContainer
    val hlText = MaterialTheme.colorScheme.onPrimaryContainer
    val annotated: AnnotatedString = remember(text, highlight, hl, hlText) {
        if (highlight == null) AnnotatedString(text) else buildAnnotatedString {
            append(text.substring(0, highlight.first))
            withStyle(SpanStyle(background = hl, color = hlText)) { append(text.substring(highlight.first, highlight.last + 1)) }
            append(text.substring(highlight.last + 1))
        }
    }
    Text(
        text = annotated,
        fontSize = (18 * fontScale).sp,
        lineHeight = (28 * fontScale).sp,
        onTextLayout = { layout = it },
        modifier = Modifier.fillMaxWidth().pointerInput(text) {
            detectTapGestures { pos -> layout?.let { onTapOffset(it.getOffsetForPosition(pos)) } }
        },
    )
}

@Composable
private fun Controls(
    chunk: Int, content: ChapterContent, playing: Boolean, buffering: Boolean,
    engine: EngineState, ready: Boolean, error: String?, sleepEndsAt: Long?,
) {
    val total = content.chunks.size
    var dragging by remember { mutableStateOf<Float?>(null) }
    Column(Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 16.dp, vertical = 8.dp)) {
        val status = when {
            error != null -> error
            engine is EngineState.Downloading -> "${engine.label} ${(engine.fraction * 100).roundToInt()}%"
            engine is EngineState.Loading -> "Loading voice…"
            engine is EngineState.Error -> engine.message.lines().first()
            buffering && playing -> "Preparing speech…"
            else -> null
        }
        if (status != null) {
            Text(status, style = MaterialTheme.typography.labelMedium,
                color = if (error != null || engine is EngineState.Error) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (total > 1) {
            Slider(
                value = dragging ?: chunk.toFloat(),
                onValueChange = { dragging = it },
                onValueChangeFinished = {
                    dragging?.let { ReaderService.seek(ReaderService.state.value.chapterIndex, it.roundToInt()) }
                    dragging = null
                },
                valueRange = 0f..(total - 1).toFloat(),
            )
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { ReaderService.stepChapter(-1) }, enabled = ready) {
                Icon(painterResource(R.drawable.ic_skip_previous), "Previous chapter")
            }
            TextButton(onClick = { ReaderService.stepChunk(-1) }, enabled = ready) { Text("◀ Sentence") }
            FilledIconButton(onClick = { ReaderService.toggle() }, enabled = ready && engine is EngineState.Ready) {
                Icon(painterResource(if (playing) R.drawable.ic_pause else R.drawable.ic_play_arrow), if (playing) "Pause" else "Play")
            }
            TextButton(onClick = { ReaderService.stepChunk(1) }, enabled = ready) { Text("Sentence ▶") }
            IconButton(onClick = { ReaderService.stepChapter(1) }, enabled = ready) {
                Icon(painterResource(R.drawable.ic_skip_next), "Next chapter")
            }
        }
        if (sleepEndsAt != null) {
            val mins = ((sleepEndsAt - System.currentTimeMillis()) / 60_000L + 1).coerceAtLeast(1)
            Text("Sleep timer: pausing in about $mins min", style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun ChapterDialog(bookId: String, current: Int, onPick: (Int) -> Unit, onDismiss: () -> Unit) {
    val meta = BookStore.get(bookId)
    val listState = rememberLazyListState(initialFirstVisibleItemIndex = (current - 2).coerceAtLeast(0))
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Chapters") },
        text = {
            LazyColumn(state = listState) {
                itemsIndexed(meta?.chapters.orEmpty()) { i, ch ->
                    Text(
                        ch.title,
                        modifier = Modifier.fillMaxWidth().clickable { onPick(i) }.padding(vertical = 12.dp)
                            .then(if (i == current) Modifier.background(MaterialTheme.colorScheme.primaryContainer) else Modifier),
                        style = MaterialTheme.typography.bodyLarge,
                        maxLines = 2, overflow = TextOverflow.Ellipsis,
                    )
                    HorizontalDivider()
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } },
    )
}

@Composable
private fun VoiceDialog(onDismiss: () -> Unit) {
    val voices by TtsRuntime.voices.collectAsState()
    val saved by ReaderPrefs.voice.collectAsState()
    val speed by ReaderPrefs.speed.collectAsState()
    val font by ReaderPrefs.fontScale.collectAsState()
    val selected = ReaderPrefs.effectiveVoice(voices)
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Voice & text") },
        text = {
            Column {
                Text("Voice", style = MaterialTheme.typography.labelLarge)
                if (voices.isEmpty()) Text("Voices appear once the model has loaded.", style = MaterialTheme.typography.bodySmall)
                Column(Modifier.padding(vertical = 4.dp)) {
                    voices.forEach { v ->
                        Row(Modifier.fillMaxWidth().clickable { ReaderPrefs.setVoice(v) }, verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(selected = v == selected, onClick = { ReaderPrefs.setVoice(v) })
                            Text(v)
                        }
                    }
                }
                Text("Speed: ${"%.2f".format(speed)}×", style = MaterialTheme.typography.labelLarge)
                Slider(value = speed, onValueChange = { ReaderPrefs.setSpeed((it * 20).roundToInt() / 20f) }, valueRange = 0.6f..1.6f)
                Text("Text size: ${(font * 100).roundToInt()}%", style = MaterialTheme.typography.labelLarge)
                Slider(value = font, onValueChange = { ReaderPrefs.setFontScale((it * 20).roundToInt() / 20f) }, valueRange = 0.8f..1.8f)
                if (saved == null && selected != null) Text("Using default voice.", style = MaterialTheme.typography.labelSmall)
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Done") } },
    )
}

@Composable
private fun SleepDialog(active: Boolean, onPick: (Int?) -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Sleep timer") },
        text = {
            Column {
                listOf(15, 30, 45, 60, 90).forEach { m ->
                    Text("$m minutes", modifier = Modifier.fillMaxWidth().clickable { onPick(m) }.padding(vertical = 12.dp),
                        style = MaterialTheme.typography.bodyLarge)
                }
                if (active) Text("Turn off timer", color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.fillMaxWidth().clickable { onPick(null) }.padding(vertical = 12.dp),
                    style = MaterialTheme.typography.bodyLarge)
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } },
    )
}
