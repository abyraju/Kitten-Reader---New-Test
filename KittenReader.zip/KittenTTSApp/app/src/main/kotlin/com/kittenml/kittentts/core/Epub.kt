package com.kittenml.kittentts.core

import org.w3c.dom.Document
import org.w3c.dom.Element
import org.xml.sax.InputSource
import java.io.File
import java.io.StringReader
import java.net.URLDecoder
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import javax.xml.parsers.DocumentBuilderFactory

data class ParsedChapter(val title: String, val paragraphs: List<String>)

data class ParsedBook(val title: String, val author: String?, val chapters: List<ParsedChapter>)

/** Reads an EPUB (spine order → plain-text chapters). No DRM support, no external libraries. */
object EpubReader {

    private const val MAX_ENTRY_BYTES = 20L * 1024 * 1024
    private const val MIN_CHAPTER_CHARS = 300
    private val CONTENTS_TITLE = Regex("^(table of )?contents$", RegexOption.IGNORE_CASE)

    private class ManifestItem(val href: String, val mediaType: String)

    fun read(file: File, fallbackTitle: String): ParsedBook {
        ZipFile(file).use { zip ->
            val entries = HashMap<String, ZipEntry>()
            for (e in zip.entries()) {
                entries[e.name] = e
                entries.putIfAbsent(e.name.lowercase(), e)
            }

            fun readText(path: String): String? {
                val entry = entries[path] ?: entries[path.lowercase()] ?: return null
                if (entry.size > MAX_ENTRY_BYTES) return null
                val text = zip.getInputStream(entry).use { it.readBytes() }.toString(Charsets.UTF_8)
                return text.removePrefix("﻿")
            }

            val container = readText("META-INF/container.xml")
                ?: throw IllegalArgumentException("Not a valid EPUB (container.xml is missing)")
            val opfPath = (parseXml(container).getElementsByTagNameNS("*", "rootfile").item(0) as? Element)
                ?.getAttribute("full-path").orEmpty()
            require(opfPath.isNotBlank()) { "Not a valid EPUB (no package document)" }

            val opf = parseXml(readText(opfPath) ?: throw IllegalArgumentException("EPUB package file is missing"))
            val base = opfPath.substringBeforeLast('/', "")

            val manifest = HashMap<String, ManifestItem>()
            val items = opf.getElementsByTagNameNS("*", "item")
            for (i in 0 until items.length) {
                val el = items.item(i) as Element
                manifest[el.getAttribute("id")] = ManifestItem(el.getAttribute("href"), el.getAttribute("media-type"))
            }

            val spine = ArrayList<String>()
            val refs = opf.getElementsByTagNameNS("*", "itemref")
            for (i in 0 until refs.length) {
                val el = refs.item(i) as Element
                if (el.getAttribute("linear").equals("no", ignoreCase = true)) continue
                spine.add(el.getAttribute("idref"))
            }

            val raw = ArrayList<ParsedChapter>()
            for (idref in spine) {
                val item = manifest[idref] ?: continue
                if (!item.mediaType.contains("html", ignoreCase = true)) continue
                val html = readText(resolve(base, item.href)) ?: continue
                val paragraphs = HtmlText.toParagraphs(html)
                if (paragraphs.sumOf { it.length } < 20) continue
                val heading = HtmlText.firstHeading(html).orEmpty()
                if (CONTENTS_TITLE.matches(heading.trim())) continue
                raw.add(ParsedChapter(heading, paragraphs))
            }

            // Fold tiny pages (title page, part dividers, dedications) into the next chapter.
            val merged = ArrayList<ParsedChapter>()
            var carry = ArrayList<String>()
            var carryTitle = ""
            for ((idx, ch) in raw.withIndex()) {
                val chars = ch.paragraphs.sumOf { it.length }
                val isLast = idx == raw.lastIndex
                if (chars < MIN_CHAPTER_CHARS && !isLast) {
                    carry.addAll(ch.paragraphs)
                    if (carryTitle.isEmpty()) carryTitle = ch.title
                    continue
                }
                merged.add(ParsedChapter(ch.title.ifBlank { carryTitle }, carry + ch.paragraphs))
                carry = ArrayList()
                carryTitle = ""
            }

            val chapters = merged.mapIndexed { i, ch ->
                ParsedChapter(ch.title.ifBlank { "Section ${i + 1}" }, ch.paragraphs)
            }
            require(chapters.isNotEmpty()) { "No readable text found in this EPUB" }

            val title = firstText(opf, "title") ?: fallbackTitle
            return ParsedBook(title, firstText(opf, "creator"), chapters)
        }
    }

    private fun firstText(doc: Document, localName: String): String? =
        doc.getElementsByTagNameNS("*", localName).item(0)?.textContent?.trim()?.takeIf { it.isNotEmpty() }

    private fun parseXml(xml: String): Document {
        val factory = DocumentBuilderFactory.newInstance()
        factory.isNamespaceAware = true
        try {
            factory.setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd", false)
        } catch (_: Exception) {
            // not supported on every parser (Android's, for one) — the resolver below covers it
        }
        val builder = factory.newDocumentBuilder()
        builder.setEntityResolver { _, _ -> InputSource(StringReader("")) }
        return builder.parse(InputSource(StringReader(xml)))
    }

    /** Resolves an href relative to the package document, decoding %20 etc. and ".." segments. */
    internal fun resolve(base: String, href: String): String {
        val clean = href.substringBefore('#').substringBefore('?')
        val decoded = try {
            URLDecoder.decode(clean.replace("+", "%2B"), "UTF-8")
        } catch (_: Exception) {
            clean
        }
        val parts = ArrayList<String>()
        val full = if (base.isEmpty()) decoded else "$base/$decoded"
        for (seg in full.split('/')) {
            when (seg) {
                "", "." -> Unit
                ".." -> if (parts.isNotEmpty()) parts.removeAt(parts.lastIndex)
                else -> parts.add(seg)
            }
        }
        return parts.joinToString("/")
    }
}
